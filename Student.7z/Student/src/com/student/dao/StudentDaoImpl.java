package com.student.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.student.entity.StudentEntity;
import com.student.model.StudentBean;

@Repository("studentDao")
public class StudentDaoImpl implements StudentDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public String insertStudent(StudentBean studentBean) {
		// TODO Auto-generated method stub
		String id = null;
		StringBuilder builder = new StringBuilder();

		try {
			StudentEntity studentEntity = new StudentEntity();
			studentEntity.setName(studentBean.getName());
			studentEntity.setCollege(studentBean.getCollege());

			sessionFactory.getCurrentSession().save(studentEntity);

			studentEntity = sessionFactory.getCurrentSession().get(StudentEntity.class, studentEntity.getId());
			builder.append("STUDENT ");
			builder.append(Long.toString(studentEntity.getId()));
			id = builder.toString();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return id;
	}

	@Override
	public List<StudentBean> viewStudents() {
		// TODO Auto-generated method stub
		List<StudentBean> studDetails = null;

		StringBuilder builder = new StringBuilder();
		try {
			List list = sessionFactory.getCurrentSession().createQuery("from StudentEntity").list();
			studDetails = new ArrayList();

			for (int i = 0; i < list.size(); i++) {
				StudentBean s = new StudentBean();
				StudentEntity studentEntity = (StudentEntity) list.get(i);
				s.setId(studentEntity.getId());
				s.setName(studentEntity.getName());
				s.setCollege(studentEntity.getCollege());

				studDetails.add(s);

			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return studDetails;
	}

	@Override
	public int destroyStudent(int id) {
		// TODO Auto-generated method stub
		try {
			StudentEntity studentEntity = new StudentEntity();
			studentEntity.setId(id);
			System.out.println("destroy");
			sessionFactory.openSession();
			sessionFactory.getCurrentSession().delete(studentEntity);
			} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 1;
	}

	@Override
	public int editStudent(StudentBean studentBean) {
		// TODO Auto-generated method stub
		try{
			StudentEntity studentEntity = new StudentEntity();
			System.out.println(studentBean.getId());
			studentEntity.setId(studentBean.getId());
			studentEntity.setName(studentBean.getName());
			studentEntity.setCollege(studentBean.getCollege());
			
			sessionFactory.getCurrentSession().saveOrUpdate(studentEntity);			
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
		return 1;
	}

	@Override
	public StudentBean viewStudent(int id) {
		// TODO Auto-generated method stub
		StudentBean studentBean = new StudentBean();

		try {
			StudentEntity studentEntity = new StudentEntity();
			
			studentEntity = (StudentEntity) sessionFactory.getCurrentSession().createQuery("from StudentEntity where id=" + id).list().get(0);
			studentBean.setId(studentEntity.getId());
			studentBean.setName(studentEntity.getName());
			studentBean.setCollege(studentEntity.getCollege());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return studentBean;
	}
}
