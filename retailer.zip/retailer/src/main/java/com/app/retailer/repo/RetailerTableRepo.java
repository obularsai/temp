package com.app.retailer.repo;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.app.retailer.entity.RetailerTableEntity;

public interface RetailerTableRepo
		extends PagingAndSortingRepository<RetailerTableEntity, Long> {

}
