package com.app.retailer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.retailer.entity.RetailerEntity;
import com.app.retailer.entity.RetailerTableEntity;
import com.app.retailer.service.RetailerService;
import com.app.retailer.service.RetailerTableService;

@RestController
@CrossOrigin

public class RetailerController {

	@Autowired
	RetailerService service;
	@Autowired
	RetailerTableService tableService;

	@GetMapping("/retailers")
	public ResponseEntity<List<RetailerEntity>> getAllRetailers() {
		List<RetailerEntity> list = service.getAllRetailers();

		return new ResponseEntity<List<RetailerEntity>>(list, new HttpHeaders(), HttpStatus.OK);
	}
	
	@GetMapping("/retailersTable")
	public ResponseEntity<List<RetailerTableEntity>> getAllRetailersTable() {
		List<RetailerTableEntity> list = tableService.getAllRetailers();

		return new ResponseEntity<List<RetailerTableEntity>>(list, new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping("/getRetailer/{id}")
	public ResponseEntity<RetailerEntity> getRetailerById(@PathVariable("id") Long id) {
		RetailerEntity entity = service.getRetailerById(id);

		return new ResponseEntity<RetailerEntity>(entity, new HttpHeaders(), HttpStatus.OK);
	}

	@PostMapping
	public ResponseEntity<RetailerEntity> createOrUpdateRetailer(RetailerEntity Retailer) {
		RetailerEntity updated = service.createOrUpdateRetailer(Retailer);
		return new ResponseEntity<RetailerEntity>(updated, new HttpHeaders(), HttpStatus.OK);
	}

	@DeleteMapping("/deleteRetailer/{id}")
	public HttpStatus deleteRetailerById(@PathVariable("id") Long id) {
		service.deleteRetailerById(id);
		return HttpStatus.FORBIDDEN;
	}

	@GetMapping("/addToTable/{id}")
	public ResponseEntity<List<RetailerTableEntity>> addToTable(@PathVariable("id") Long id) {
		RetailerEntity entity = service.getRetailerById(id);
		tableService.createOrUpdateRetailer(entity);
		List<RetailerTableEntity> list = tableService.getAllRetailers();
		return new ResponseEntity<List<RetailerTableEntity>>(list, new HttpHeaders(), HttpStatus.OK);
	}

}
