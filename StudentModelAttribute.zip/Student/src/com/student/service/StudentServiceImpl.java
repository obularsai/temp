package com.student.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.student.dao.StudentDao;
import com.student.model.StudentBean;

@Service("studentService")
@Transactional
public class StudentServiceImpl implements StudentService {
    
	@Autowired
	StudentDao studentDao;
	
	@Override
	public int destroyStudent(int id) {
		// TODO Auto-generated method stub
		return studentDao.destroyStudent(id);
	}
	
	@Override
	public List<StudentBean> viewStudents() {
		// TODO Auto-generated method stub
		return studentDao.viewStudents();
	}
	
	@Override
	public String insertStudent(StudentBean studentBean) {
		// TODO Auto-generated method stub
		return studentDao.insertStudent(studentBean);
	}
	
	@Override
	public int editStudent(StudentBean studentBean) {
		// TODO Auto-generated method stub
		return studentDao.editStudent(studentBean);
	}
	
	@Override
	public StudentBean viewStudent(int id) {
		// TODO Auto-generated method stub
		return studentDao.viewStudent(id);
	}
	
}
