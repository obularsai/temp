package com.smgmt.service;

import java.util.List;

import com.smgmt.bean.Student;
import com.smgmt.dao.StudentDao;
import com.smgmt.dao.StudentDaoImpl;

public class StudentServiceImpl implements StudentService {

	StudentDao sdao = new StudentDaoImpl();
	
	@Override
	public String insertStudent(Student s) {
		// TODO Auto-generated method stub
		return sdao.insertStudent(s);
	}

	@Override
	public int deleteStudent(Student s) {
		// TODO Auto-generated method stub
		return sdao.deleteStudent(s);
	}

	@Override
	public List<Student> fetchStudents() {
		// TODO Auto-generated method stub
		return sdao.fetchStudents();
	}

	@Override
	public int updateStudent(Student s) {
		// TODO Auto-generated method stub
		return sdao.updateStudent(s);
	}

	@Override
	public Student fetchStudent(int id) {
		// TODO Auto-generated method stub
		return sdao.fetchStudent(id);
	}

}
