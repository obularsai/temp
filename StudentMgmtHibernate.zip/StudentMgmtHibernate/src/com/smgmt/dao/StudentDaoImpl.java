package com.smgmt.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.smgmt.bean.Student;
import com.smgmt.entity.StudentEntity;

public class StudentDaoImpl implements StudentDao {

	@Override
	public String insertStudent(Student s) {
		// TODO Auto-generated method stub
		SessionFactory sessionfactory = null;
		Session session = null;
		String id = null;

		StringBuilder builder = new StringBuilder();

		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			Transaction transaction = session.beginTransaction();
			StudentEntity studentEntity = new StudentEntity();
			// System.out.println(s.getName());
			studentEntity.setName(s.getName());
			studentEntity.setDepartment(s.getDepartment());
			studentEntity.setCollege(s.getCollege());

			session.save(studentEntity);
			transaction.commit();

			studentEntity = session.get(StudentEntity.class, studentEntity.getId());
			builder.append("STUDENT ");
			builder.append(Long.toString(studentEntity.getId()));
			id = builder.toString();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return id;
	}

	@Override
	public int deleteStudent(Student s) {
		// TODO Auto-generated method stub
		SessionFactory sessionfactory = null;
		Session session = null;
		// String id = null;

		// StringBuilder builder = new StringBuilder();
		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			Transaction transaction = session.beginTransaction();
			StudentEntity studentEntity = new StudentEntity();

			studentEntity.setId(s.getId());

			session.delete(studentEntity);
			transaction.commit();

			// studentEntity = session.get(StudentEntity.class,
			// studentEntity.getId());
			// builder.append("STUDENT ");
			// builder.append(Long.toString(studentEntity.getId()));
			// id = builder.toString();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 1;
	}

	@Override
	public List<Student> fetchStudents() {
		// TODO Auto-generated method stub
		SessionFactory sessionfactory = null;
		Session session = null;
		List<Student> studDetails = null;

		StringBuilder builder = new StringBuilder();
		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			List list = session.createQuery("from StudentEntity").list();
			studDetails = new ArrayList();

			for (int i = 0; i < list.size(); i++) {
				Student s= new Student();
				StudentEntity studentEntity = (StudentEntity) list.get(i);
				s.setId(studentEntity.getId());
				s.setName(studentEntity.getName());
				s.setDepartment(studentEntity.getDepartment());
				s.setCollege(studentEntity.getCollege());			
				builder.append("STUDENT");
				builder.append(Long.toString(studentEntity.getId()));			
				studDetails.add(s);
				
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return studDetails;
	}

	@Override
	public int updateStudent(Student s) {
		// TODO Auto-generated method stub
		SessionFactory sessionfactory = null;
		Session session = null;
		
		try{
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			
			StudentEntity studentEntity = new StudentEntity();

			studentEntity.setId(s.getId());
			studentEntity.setName(s.getName());
			studentEntity.setDepartment(s.getDepartment());
			studentEntity.setCollege(s.getCollege());
			
			Transaction transaction = session.beginTransaction();
			session.update(studentEntity);
			transaction.commit();			
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
		return 1;
	}

	@Override
	public Student fetchStudent(int id) {
		// TODO Auto-generated method stub
		SessionFactory sessionfactory = null;
		Session session = null;
		List<Student> studDetails = null;
		Student s = new Student();

		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			List list = session.createQuery("from StudentEntity where id=" + id).list();
			studDetails = new ArrayList();
			for (int i = 0; i < list.size(); i++) {
				StudentEntity studentEntity = (StudentEntity) list.get(i);
				s.setId(studentEntity.getId());
				s.setName(studentEntity.getName());
				s.setDepartment(studentEntity.getDepartment());
				s.setCollege(studentEntity.getCollege());
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return s;
	}
}
