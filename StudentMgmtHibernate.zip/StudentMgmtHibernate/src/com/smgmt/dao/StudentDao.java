package com.smgmt.dao;

import java.util.List;

import com.smgmt.bean.Student;

public interface StudentDao {

	public String insertStudent(Student s);

	public int deleteStudent(Student s);

	public List<Student> fetchStudents();

	public int updateStudent(Student s);

	public Student fetchStudent(int id);
}
