package com.cms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cms.bean.TermsAndConditionsBean;
import com.cms.service.TermsAndConditionsService;

@Controller
public class TermsAndConditionsController {

	@Autowired
	TermsAndConditionsService tacService;
	
	@RequestMapping("/fetchTermsAndConditions")
	public ModelAndView fetchTermsAndConditions(@RequestParam("contractId") int contractId){
		TermsAndConditionsBean tacBean = new TermsAndConditionsBean();
		
		tacBean = tacService.fetchTermsAndConditions(contractId);
		return new ModelAndView("updateTermsAndConditions", "tacBean", tacBean);
	}
}
