package com.cms.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.jasper.tagplugins.jstl.core.Remove;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cms.bean.SupplierBean;
import com.cms.service.ContractService;
import com.cms.service.SupplierService;
import com.cms.bean.ContractBean;

@Controller
public class SupplierController {
	@Autowired
	SupplierService supplierService;
	
	@Autowired
	ContractService contractService;
	
	@RequestMapping(value = "/loginSupplier", method = RequestMethod.POST)
	public ModelAndView loginSupplier(@RequestParam("firstName") String name,@RequestParam("password") String password){
		
		SupplierBean supplierBean;
		List<ContractBean> contractList,contractList1 = new ArrayList<ContractBean>();
		
		Map<String, Object> model = new HashMap<String, Object>();
		
		contractList = contractService.listContract();
		supplierBean = supplierService.loginSupplierCheck(name);
		
		for(ContractBean contract : contractList){
			if(contract.getSupplierId() == supplierBean.getSupplierId()){
				contractList1.add(contract);
			}
		}
		
		model.put("contractList",contractList1);
		model.put("supplierBean", supplierBean);
		
		if(password.equals(supplierBean.getPassword())){
			return new ModelAndView("supplierPage", model);
		} else 
			return new ModelAndView("error");
	}
	
	@RequestMapping(value = "/addSupplier", method = RequestMethod.POST)
	public ModelAndView saveSupplier(@ModelAttribute("command") SupplierBean supplierBean, BindingResult result) {
		int id = 0;
		id=supplierService.addSupplier(supplierBean);
		System.out.println(id);
		if (id != 0)
			return new ModelAndView("index");
		else
			return new ModelAndView("error");
	}
}
