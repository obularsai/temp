package com.cms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cms.bean.ContractBean;
import com.cms.service.ContractService;

public class AmenityController {

	@Autowired
	ContractService contractService;
	
	@RequestMapping("/addAmenity")
	public ModelAndView addAmenity(@ModelAttribute("command") ContractBean contractBean, BindingResult result){
		int i = contractService.addContract(contractBean);
		if(i != 0)
			return new ModelAndView("supplierPage");
		else
			return new ModelAndView("error");
	}
}
