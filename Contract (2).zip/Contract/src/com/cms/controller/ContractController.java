package com.cms.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cms.bean.ContractBean;
import com.cms.service.ContractService;

@Controller
public class ContractController {

	@Autowired
	ContractService contractService;
	
	@RequestMapping("/addContract")
	public ModelAndView addContract(@ModelAttribute("command") ContractBean contractBean, BindingResult result){
		List<ContractBean> contractList = new ArrayList<ContractBean>();
		contractList = contractService.listContract();
		int i = contractService.addContract(contractBean);
		if(i != 0)
			return new ModelAndView("supplierPage", "contractList",contractList);
		else
			return new ModelAndView("error");
	}
	
	@RequestMapping("/contractList")
	public ModelAndView listContract(){
		List<ContractBean> contractList = new ArrayList<ContractBean>();
		contractList = contractService.listContract();
		if(contractList != null)
			return new ModelAndView("supplierPage", "contractList", contractList);
		else
			return new ModelAndView("error");
	}
}
