package com.cms.dao;

import com.cms.bean.TermsAndConditionsBean;

public interface TermsAndConditionsDao {

	public TermsAndConditionsBean fetchTermsAndConditions(int contractId);
}
