package com.cms.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.bean.TermsAndConditionsBean;
import com.cms.entity.TermsAndConditionsEntity;

@Repository("tacDao")
public class TermsAndConditionsDaoImpl implements TermsAndConditionsDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public TermsAndConditionsBean fetchTermsAndConditions(int contractId) {
		// TODO Auto-generated method stub
		TermsAndConditionsBean tacBean = new TermsAndConditionsBean();

		try {
			TermsAndConditionsEntity tacEntity = new TermsAndConditionsEntity();

			tacEntity = (TermsAndConditionsEntity) sessionFactory.getCurrentSession()
					.createQuery("from TermsAndConditionsEntity where contractId=" + contractId).list().get(0);
			tacBean.setContractId(tacEntity.getContractId());
			tacBean.setTerm(tacEntity.getTerm());
			tacBean.setCondition(tacEntity.getCondition());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return tacBean;
	}
}
