package com.cms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="amenity")
public class AmenityEntity {
	
	@Column(name="amenities1")
	private String amenities1;
	@Column(name="amenities2")
	private String amenities2;
	@Column(name="amenities3")
	private String amenities3;
	@Column(name="amenities4")
	private String amenities4;
	@Column(name="amenities5")
	private String amenities5;
	@Column(name="other_info")
	private String otherInfo;
	@Column(name="contract_id")
	private int contractId;
	
	
	public int getContractId() {
		return contractId;
	}
	public void setContractId(int contractId) {
		this.contractId = contractId;
	}
	public String getAmenities1() {
		return amenities1;
	}
	public void setAmenities1(String amenities1) {
		this.amenities1 = amenities1;
	}
	public String getAmenities2() {
		return amenities2;
	}
	public void setAmenities2(String amenities2) {
		this.amenities2 = amenities2;
	}
	public String getAmenities3() {
		return amenities3;
	}
	public void setAmenities3(String amenities3) {
		this.amenities3 = amenities3;
	}
	public String getAmenities4() {
		return amenities4;
	}
	public void setAmenities4(String amenities4) {
		this.amenities4 = amenities4;
	}
	public String getAmenities5() {
		return amenities5;
	}
	public void setAmenities5(String amenities5) {
		this.amenities5 = amenities5;
	}
	public String getOtherInfo() {
		return otherInfo;
	}
	public void setOtherInfo(String otherInfo) {
		this.otherInfo = otherInfo;
	}
}
