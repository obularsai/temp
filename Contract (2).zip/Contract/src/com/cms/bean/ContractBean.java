package com.cms.bean;

public class ContractBean {

	private int contractId;
	private String contractDesc;
	private String contractSubDate;
	private String contractProDate;
	private String contractStatus;
	private int supplierId;

	public int getContractId() {
		return contractId;
	}

	public void setContractId(int contractId) {
		this.contractId = contractId;
	}

	public String getContractDesc() {
		return contractDesc;
	}

	public void setContractDesc(String contractDesc) {
		this.contractDesc = contractDesc;
	}

	public String getContractSubDate() {
		return contractSubDate;
	}

	public void setContractSubDate(String contractSubDate) {
		this.contractSubDate = contractSubDate;
	}

	public String getContractProDate() {
		return contractProDate;
	}

	public void setContractProDate(String contractProDate) {
		this.contractProDate = contractProDate;
	}

	public String getContractStatus() {
		return contractStatus;
	}

	public void setContractStatus(String contractStatus) {
		this.contractStatus = contractStatus;
	}

	public int getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}

}
