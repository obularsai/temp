package com.cms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cms.bean.TermsAndConditionsBean;
import com.cms.dao.TermsAndConditionsDao;

@Service("tacService")
@Transactional
public class TermsAndConditionsServiceImpl implements TermsAndConditionsService{

	@Autowired
	TermsAndConditionsDao tacDao;
	
	@Override
	public TermsAndConditionsBean fetchTermsAndConditions(int contractId) {
		// TODO Auto-generated method stub
		return tacDao.fetchTermsAndConditions(contractId);
	}

	
}
