package com.cms.service;

import java.util.List;

import com.cms.bean.ContractBean;

public interface ContractService {

	public int addContract(ContractBean contractBean);
	
	public List<ContractBean> listContract();
}
