package com.cms.service;

import com.cms.bean.TermsAndConditionsBean;

public interface TermsAndConditionsService {

	public TermsAndConditionsBean fetchTermsAndConditions(int contractId);
}
