package com.cms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cms.bean.SupplierBean;
import com.cms.dao.SupplierDao;



@Service("supplierService")
@Transactional
public class SupplierServiceImpl implements SupplierService {

	@Autowired
	SupplierDao supplierDao;
	
	@Override
	public SupplierBean loginSupplierCheck(String name) {
		// TODO Auto-generated method stub
		return supplierDao.loginSupplierCheck(name);

	}

	@Override
	public int addSupplier(SupplierBean supplierBean) {
		// TODO Auto-generated method stub
		return supplierDao.addSupplier(supplierBean);
	}

}
