package com.cms.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.bean.AdminBean;
import com.cms.entity.AdminEntity;
import com.cms.entity.SupplierEntity;



@Repository("adminDao")
public class AdminDaoImpl implements AdminDao {
	

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public int addAdmin(AdminBean adminBean) {
		// TODO Auto-generated method stub
		try {
			AdminEntity adminEntity = new AdminEntity();
			adminEntity.setFirstName(adminBean.getFirstName());
			adminEntity.setLastName(adminBean.getLastName());
			adminEntity.setAge(adminBean.getAge());
			adminEntity.setGender(adminBean.getGender());
			adminEntity.setDob(adminBean.getDob());
			adminEntity.setContactNumber(adminBean.getContactNumber());
			adminEntity.setAltContactNumber(adminBean.getAltContactNumber());
			adminEntity.setEmailId(adminBean.getEmailId());
			adminEntity.setPassword(adminBean.getPassword());
			
			sessionFactory.getCurrentSession().saveOrUpdate(adminEntity);

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 1;
	}

	@Override
	public String loginAdminCheck(String name) {
		// TODO Auto-generated method stub
		AdminEntity adminEntity = null;
		try{
			adminEntity = (AdminEntity) sessionFactory.getCurrentSession().createQuery("from AdminEntity where firstName='"+name+"'").list().get(0);
			System.out.println(adminEntity.getPassword());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		System.out.println(adminEntity.getPassword());
		return adminEntity.getPassword();
	}

	

	
}
