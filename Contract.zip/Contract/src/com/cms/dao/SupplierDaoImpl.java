package com.cms.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.bean.SupplierBean;
import com.cms.entity.SupplierEntity;

@Repository("supplierDao")
public class SupplierDaoImpl implements SupplierDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public SupplierBean loginSupplierCheck(String name) {
		SupplierEntity supplierEntity = null;
		SupplierBean supplierBean = new SupplierBean();
		try{
			supplierEntity = (SupplierEntity) sessionFactory.getCurrentSession().createQuery("from SupplierEntity where firstName='"+name+"'").list().get(0);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		supplierBean.setFirstName(supplierEntity.getFirstName());
		supplierBean.setLastName(supplierEntity.getLastName());
		supplierBean.setPassword(supplierEntity.getPassword());
		supplierBean.setSupplierId(supplierEntity.getSupplierId());
		return supplierBean;
	}


	@Override
	public int addSupplier(SupplierBean supplierBean) {
		try
		{
			SupplierEntity supplierEntity = new SupplierEntity();
			supplierEntity.setFirstName(supplierBean.getFirstName());
			supplierEntity.setLastName(supplierBean.getLastName());
			supplierEntity.setAge(supplierBean.getAge());
			supplierEntity.setGender(supplierBean.getGender());
			supplierEntity.setDob(supplierBean.getDob());
			supplierEntity.setContactNumber(supplierBean.getContactNumber());
			supplierEntity.setAltContactNumber(supplierBean.getAltContactNumber());
			supplierEntity.setEmailId(supplierBean.getEmailId());
			supplierEntity.setPassword(supplierBean.getPassword());
			supplierEntity.setAddressLine1(supplierBean.getAddressLine1());
			supplierEntity.setAddressLine2(supplierBean.getAddressLine2());
			supplierEntity.setCity(supplierBean.getCity());
			supplierEntity.setState(supplierBean.getState());
			supplierEntity.setZipCode(supplierBean.getZipCode());
			sessionFactory.getCurrentSession().saveOrUpdate(supplierEntity);
	}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 1;
	}
}

