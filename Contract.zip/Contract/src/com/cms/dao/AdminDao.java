package com.cms.dao;

import com.cms.bean.AdminBean;

public interface AdminDao {

	public int addAdmin(AdminBean adminBean);
	
	public String loginAdminCheck(String name);

}
