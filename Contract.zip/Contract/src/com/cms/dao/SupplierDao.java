package com.cms.dao;

import com.cms.bean.SupplierBean;

public interface SupplierDao {

	
	
	public String loginSupplierCheck(String name);

	public int addSupplier(SupplierBean supplierBean);
	
}
