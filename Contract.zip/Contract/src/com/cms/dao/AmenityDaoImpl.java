package com.cms.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.bean.ContractBean;
import com.cms.entity.AmenityEntity;
import com.cms.entity.TermsAndConditionsEntity;

@Repository("amenityDao")
public class AmenityDaoImpl implements AmenityDao{

	@Autowired
	SessionFactory sessionFactory;

	@Override
	public int addAmenity(ContractBean contractBean) {
		// TODO Auto-generated method stub
		try {
			AmenityEntity amenityEntity = new AmenityEntity();
			
			amenityEntity.setContractId(contractBean.getContractId());
			amenityEntity.setAmenity1(contractBean.getAmenity1());

			sessionFactory.getCurrentSession().saveOrUpdate(amenityEntity);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 1;
	}
	
//	@Override
//	public ContractBean fetchAmenity(int contractId) {
//		// TODO Auto-generated method stub
//		ContractBean amenityBean = new ContractBean();
//
//		try {
//			AmenityEntity amenityEntity = new AmenityEntity();
//
//			amenityEntity = (AmenityEntity) sessionFactory.getCurrentSession()
//					.createQuery("from TermsAndConditionsEntity where contractId=" + contractId).list().get(0);
//			amenityBean.setContractId(amenityEntity.getContractId());
//			amenityBean.setAmenity(amenityEntity.getAmenity1());
//
//		} catch (Exception e) {
//			System.out.println(e.getMessage());
//		}
//		return amenityBean;
//	}

}
