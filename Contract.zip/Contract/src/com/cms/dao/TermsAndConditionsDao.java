package com.cms.dao;

import com.cms.bean.ContractBean;

public interface TermsAndConditionsDao {

	public int addTac(ContractBean contractBean);
	
	public int updateTac(ContractBean contractBean);
}
