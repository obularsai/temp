package com.cms.dao;

import java.util.List;

import com.cms.bean.ContractBean;


public interface ContractDao {

	public int addContract(ContractBean contractBean);
 
	public List<ContractBean> listContract();
}
