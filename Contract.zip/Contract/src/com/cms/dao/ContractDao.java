package com.cms.dao;

import java.util.List;

import com.cms.bean.ContractBean;


public interface ContractDao {

	public int addContract(ContractBean contractBean);
 
	public List<ContractBean> listContract();
	
	public ContractBean fetchContract(int contractId);
	
	public int updateContract(ContractBean contractBean);
	
	public int deleteContract(int contractId);
	
}
