package com.cms.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cms.bean.ContractBean;
import com.cms.service.AmenityService;
import com.cms.service.ContractService;
import com.cms.service.TermsAndConditionsService;

@Controller
public class ContractController {

	@Autowired
	ContractService contractService;
	@Autowired
	TermsAndConditionsService tacService;
	@Autowired
	AmenityService amenityService;

	@RequestMapping(value = "/addContract", method = RequestMethod.GET)
	public ModelAndView addContract(@ModelAttribute("command") ContractBean contractBean, BindingResult result) {

		List<ContractBean> contractList = new ArrayList<ContractBean>();

		int id = contractService.addContract(contractBean);
		tacService.addTac(contractBean);
		amenityService.addAmenity(contractBean);

		contractList = contractService.listContract();
		if (id != 0) {
			return new ModelAndView("supplier", "contractList", contractList);
		} else
			return new ModelAndView("error");
	}

	@RequestMapping(value = "/fetchContract", method = RequestMethod.GET)
	public ModelAndView fetchContract(@RequestParam("contractId") int contractId) {

		ContractBean contractBean = new ContractBean();
		contractBean = contractService.fetchContract(contractId);

		if (contractBean != null) {
			return new ModelAndView("editContract", "contractBean", contractBean);
		} else
			return new ModelAndView("error");
	}

	@RequestMapping(value = "/updateContract", method = RequestMethod.GET)
	public ModelAndView updateContract(@ModelAttribute("command") ContractBean contractBean, BindingResult result) {

		List<ContractBean> contractList = new ArrayList<ContractBean>();

		int i = contractService.updateContract(contractBean);
		tacService.updateTac(contractBean);
		amenityService.updateAmenity(contractBean);

		contractList = contractService.listContract();
		if (i != 0) {
			return new ModelAndView("supplier", "contractList", contractList);
		} else
			return new ModelAndView("error");
	}

	@RequestMapping(value = "/deleteContract", method = RequestMethod.GET)
	public ModelAndView deleteContract(@RequestParam("contractId") int contractId, HttpSession session) {

		int i = 0;
		List<ContractBean> contractList = new ArrayList<ContractBean>();
		if(session.getAttribute("supplierBean") == null){
			return new ModelAndView("index");
		}
		i = contractService.deleteContract(contractId);
		contractList = contractService.listContract();
		if (i != 0) {
			return new ModelAndView("supplier", "contractList", contractList);
		} else
			return new ModelAndView("error");
	}
}
