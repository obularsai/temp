package com.cms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cms.bean.AdminBean;
import com.cms.service.AdminService;

@Controller
public class AdminController {

	@Autowired
	AdminService adminService;

	@RequestMapping(value = "/addAdmin", method = RequestMethod.POST)
	public ModelAndView saveAdmin(@ModelAttribute("command") AdminBean adminBean, BindingResult result) {
		int id = 0;
		id=adminService.addAdmin(adminBean);
		if (id != 0)
			return new ModelAndView("index");
		else
			return new ModelAndView("error");
	}
	
	
	
	@RequestMapping(value = "/loginAdmin", method = RequestMethod.POST)
	public ModelAndView loginAdmin(@RequestParam("firstName") String name,@RequestParam("password") String password){
		String password1 = null;
		
		password1 = adminService.loginAdminCheck(name);
		if(password.equals(password1)){
			return new ModelAndView("index");
		} else 
			return new ModelAndView("error");
	}
	
	
//	private AdminBean prepareModel(AdminBean adminBean) {
//		adminBean.setFirstName(adminBean.getFirstName());
//		adminBean.setLastName(adminBean.getLastName());
//		adminBean.setAge(adminBean.getAge());
//		adminBean.setGender(adminBean.getGender());
//		adminBean.setDob(adminBean.getDob());
//		adminBean.setContactNumber(adminBean.getContactNumber());
//		adminBean.setAltContactNumber(adminBean.getAltContactNumber());
//		adminBean.setEmailId(adminBean.getEmailId());
//
//		return adminBean;
//	}

}
