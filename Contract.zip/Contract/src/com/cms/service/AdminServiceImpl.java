package com.cms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cms.bean.AdminBean;
import com.cms.dao.AdminDao;

@Service("adminService")
@Transactional
public class AdminServiceImpl implements AdminService {

	@Autowired
	AdminDao adminDao;

	@Override
	public int addAdmin(AdminBean adminBean) {
		// TODO Auto-generated method stub

		return adminDao.addAdmin(adminBean);
	}

	@Override
	public String loginAdminCheck(String name) {
		// TODO Auto-generated method stub
		return adminDao.loginAdminCheck(name);
	}

	
}
