package com.cms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cms.bean.ContractBean;
import com.cms.dao.ContractDao;

@Service("contractService")
@Transactional
public class ContractServiceImpl implements ContractService {

	@Autowired
	ContractDao contractDao;
	
	@Override
	public int addContract(ContractBean contractBean) {
		// TODO Auto-generated method stub
		return contractDao.addContract(contractBean);
	}

	@Override
	public List<ContractBean> listContract() {
		// TODO Auto-generated method stub
		return contractDao.listContract();
	}

	@Override
	public ContractBean fetchContract(int contractId) {
		// TODO Auto-generated method stub
		return contractDao.fetchContract(contractId);
	}

	@Override
	public int updateContract(ContractBean contractBean) {
		// TODO Auto-generated method stub
		return contractDao.updateContract(contractBean);
	}

	@Override
	public int deleteContract(int contractId) {
		// TODO Auto-generated method stub
		return contractDao.deleteContract(contractId);
	}

}
