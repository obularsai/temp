package com.cms.service;

import com.cms.bean.ContractBean;

public interface TermsAndConditionsService {

	public int addTac(ContractBean contractBean);
	
}
