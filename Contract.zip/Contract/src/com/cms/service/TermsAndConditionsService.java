package com.cms.service;

import java.util.List;

import com.cms.bean.ContractBean;

public interface TermsAndConditionsService {

	public int addTac(ContractBean contractBean);
	
	public int updateTac(ContractBean contractBean);
	
	public List<ContractBean> listTac();
}
