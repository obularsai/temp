package com.medicare.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.dao.ApplicationException;
import com.medicare.dao.CustomerDao;
import com.medicare.pojo.CustomerPojo;
import com.medicare.pojo.TestResultPojo;

@Service
public class CustomerServiceImpl implements CustomerService
{
	@Autowired
	CustomerDao customerDao;
	
	public int addCustomer(CustomerPojo pojo) throws ApplicationException
	{
		return customerDao.addCustomer(pojo);
	}

	public int loginCustomer(CustomerPojo pojo) throws ApplicationException
	{
		return customerDao.loginCustomer(pojo);
	}

	public ArrayList fetchMedicare() throws ApplicationException 
	{
		return customerDao.fetchMedicare();	
	}

	public int insertRequest(TestResultPojo resultPojo) throws ApplicationException
	{
		return customerDao.insertRequest(resultPojo);
	}

	public ArrayList fetchPendingResult(int customerId) throws ApplicationException 
	{
           return customerDao.fetchPendingResult(customerId);
	}

	public ArrayList fetchCompletedResult(int customerId) throws ApplicationException 
	{
	      return customerDao.fetchCompletedResult(customerId);
	};
}
