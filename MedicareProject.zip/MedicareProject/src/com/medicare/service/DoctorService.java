package com.medicare.service;

import java.util.ArrayList;
import java.util.List;

import com.medicare.dao.ApplicationException;
import com.medicare.pojo.DoctorPojo;
import com.medicare.pojo.MedicareServicePojo;
import com.medicare.pojo.TestResultPojo;

public interface DoctorService 
{
	public int addDoctor(DoctorPojo doctorPojo) throws ApplicationException;

	public int loginDoctor(DoctorPojo doctorPojo) throws ApplicationException;

	public List<MedicareServicePojo> fetchAllMedicareServices() throws ApplicationException;

	public ArrayList fetchDoctor() throws ApplicationException;

	public int updatePendingResult(TestResultPojo resultPojo) throws ApplicationException;

	public ArrayList fetchPendingResult(int doctorId) throws ApplicationException;

	public ArrayList fetchCompletedResult(int doctorId) throws ApplicationException;

	public int deletePendingResult(int testResultId) throws ApplicationException;

	public int updateMedicareServices(MedicareServicePojo medicareServicePojo) throws ApplicationException;

	public List<MedicareServicePojo> fetchMedicareServices(int serviceId) throws ApplicationException;
}
