package com.medicare.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.dao.ApplicationException;
import com.medicare.dao.DoctorDao;
import com.medicare.pojo.DoctorPojo;
import com.medicare.pojo.MedicareServicePojo;
import com.medicare.pojo.TestResultPojo;

@Service
public class DoctorServiceImpl implements DoctorService
{
	@Autowired
	DoctorDao doctorDao;
	
	public int addDoctor(DoctorPojo doctorPojo) throws ApplicationException
	{
		return doctorDao.addDoctor(doctorPojo);
	}

	public int loginDoctor(DoctorPojo doctorPojo) throws ApplicationException
	{
		return doctorDao.loginDoctor(doctorPojo);
	}

	public List<MedicareServicePojo> fetchAllMedicareServices() throws ApplicationException
	{
		return doctorDao.fetchAllMedicareServices();
	}

	
	public ArrayList fetchDoctor() throws ApplicationException 
	{
		return doctorDao.fetchDoctor();
	}

	public int updatePendingResult(TestResultPojo resultPojo) throws ApplicationException
	{
	   return doctorDao.updatePendingResult(resultPojo);
	}
	
	public ArrayList fetchPendingResult(int doctorId) throws ApplicationException 
	{
	    return doctorDao.fetchPedingResult(doctorId);
	}

	public ArrayList fetchCompletedResult(int doctorId) throws ApplicationException 
	{
		return doctorDao.fetchCompletedResult(doctorId);
	}

	
	public int deletePendingResult(int testResultId) throws ApplicationException 
	{
		return doctorDao.deletePendingResult(testResultId);
	}

	public int updateMedicareServices(MedicareServicePojo medicareServicePojo) throws ApplicationException 
	{
		return doctorDao.updateMedicareServices(medicareServicePojo);
	}


	public List<MedicareServicePojo> fetchMedicareServices(int serviceId) throws ApplicationException 
	{
		return doctorDao.fetchMedicareServices(serviceId);
	}
}
