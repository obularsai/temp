package com.medicare.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.dao.AdminDao;
import com.medicare.dao.ApplicationException;
import com.medicare.pojo.AdminPojo;

@Service
public class AdminServiceImpl implements AdminService
{
	@Autowired
	AdminDao adminDao;
	
	public int addAdmin(AdminPojo adminPojo) throws ApplicationException
	{
		return adminDao.addAdmin(adminPojo);
	}

	public int loginAdmin(AdminPojo adminPojo) throws ApplicationException
	{
		return adminDao.loginAdmin(adminPojo);
	}

}
