package com.medicare.service;

import com.medicare.dao.ApplicationException;
import com.medicare.pojo.AdminPojo;

public interface AdminService 
{
	public int addAdmin(AdminPojo adminPojo) throws ApplicationException;


	public int loginAdmin(AdminPojo adminPojo) throws ApplicationException;


}
