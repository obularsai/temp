package com.medicare.dao;

import com.medicare.pojo.AdminPojo;

public interface AdminDao 
{
	public int addAdmin(AdminPojo adminPojo) throws ApplicationException;

	public int loginAdmin(AdminPojo adminPojo) throws ApplicationException;
;
}
