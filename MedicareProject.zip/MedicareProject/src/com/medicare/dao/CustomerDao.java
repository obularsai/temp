package com.medicare.dao;

import java.util.ArrayList;

import com.medicare.pojo.CustomerPojo;
import com.medicare.pojo.TestResultPojo;

public interface CustomerDao 
{
	public int addCustomer(CustomerPojo pojo) throws ApplicationException;

	public int loginCustomer(CustomerPojo customerPojo) throws ApplicationException;

	public ArrayList fetchMedicare() throws ApplicationException;

	public int insertRequest(TestResultPojo resultPojo) throws ApplicationException;

	public ArrayList fetchPendingResult(int customerId) throws ApplicationException;

	public ArrayList fetchCompletedResult(int customerId) throws ApplicationException;
}
