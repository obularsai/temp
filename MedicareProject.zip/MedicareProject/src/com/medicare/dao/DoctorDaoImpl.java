package com.medicare.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.medicare.entity.DoctorEntity;
import com.medicare.entity.MedicareServiceEntity;
import com.medicare.entity.TestResultEntity;
import com.medicare.pojo.DoctorPojo;
import com.medicare.pojo.MedicareServicePojo;
import com.medicare.pojo.TestResultPojo;

@Repository
public class DoctorDaoImpl implements DoctorDao
{
	public int addDoctor(DoctorPojo doctorPojo) throws ApplicationException
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
        Transaction tx = session.beginTransaction();
        
        int rowAffected=0;
        
        try
        {
       	 
       	 DoctorEntity doctorEntity=new DoctorEntity();
        
       	 doctorEntity.setId(doctorPojo.getId());
       	 doctorEntity.setFirstName(doctorPojo.getFirstName());
       	 doctorEntity.setLastName(doctorPojo.getLastName());
       	 doctorEntity.setAge(doctorPojo.getAge());
       	 doctorEntity.setGender(doctorPojo.getGender());
       	 doctorEntity.setDob(doctorPojo.getDob());
       	 doctorEntity.setNumber(doctorPojo.getNumber());
       	 doctorEntity.setAltNumber(doctorPojo.getAltNumber());
       	 doctorEntity.setEmailId(doctorPojo.getEmailId());
       	 doctorEntity.setPassword(doctorPojo.getPassword());
       	 doctorEntity.setAddress1(doctorPojo.getAddress1());
       	 doctorEntity.setAddress2(doctorPojo.getAddress2());
       	 doctorEntity.setCity(doctorPojo.getCity());
       	 doctorEntity.setState(doctorPojo.getState());
       	 doctorEntity.setZipCode(doctorPojo.getZipCode());
       	 doctorEntity.setDegree(doctorPojo.getDegree());
       	 doctorEntity.setSpeciality(doctorPojo.getSpeciality());
       	 doctorEntity.setWorkHours(doctorPojo.getWorkHours());
       	 doctorEntity.setClinicName(doctorPojo.getClinicName());
         
       	MedicareServiceEntity medicareEntity = session.load(MedicareServiceEntity.class, doctorPojo.getServiceId());
         doctorEntity.setMedicareService(medicareEntity);
  
       	 session.save(doctorEntity);
         tx.commit();
         
         rowAffected=1;
        }
        catch(HibernateException e)
     	 {
     		if (tx!=null) 
     			tx.rollback();
     		throw new ApplicationException(e.getMessage());
     	 }
     	 finally
     	 {
     		session.close();
     	 }
   	 return rowAffected;
	}

	public int loginDoctor(DoctorPojo doctorPojo) throws ApplicationException
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
        int value=0;
        try
        {
       	 List list = session.createQuery("from DoctorEntity").list();

			for (int i = 0; i < list.size(); i++) 
			{
				DoctorEntity doctorEntity = (DoctorEntity) list.get(i);
				if(doctorPojo.getFirstName().equals(doctorEntity.getFirstName())&&(doctorPojo.getPassword().equals(doctorEntity.getPassword())))
				{
					value=1;
					
					doctorPojo.setId(doctorEntity.getId());
					doctorPojo.setFirstName(doctorEntity.getFirstName());
					doctorPojo.setLastName(doctorEntity.getLastName());
					doctorPojo.setAge(doctorEntity.getAge());
					doctorPojo.setGender(doctorEntity.getGender());
					doctorPojo.setDob(doctorEntity.getDob());
					doctorPojo.setEmailId(doctorEntity.getEmailId());
					doctorPojo.setNumber(doctorEntity.getNumber());
					doctorPojo.setAltNumber(doctorEntity.getAltNumber());
					doctorPojo.setAddress1(doctorEntity.getAddress1());
					doctorPojo.setAddress2(doctorEntity.getAddress2());
					doctorPojo.setCity(doctorEntity.getCity());
					doctorPojo.setState(doctorEntity.getState());
					doctorPojo.setZipCode(doctorEntity.getZipCode());
					doctorPojo.setDegree(doctorEntity.getDegree());
					doctorPojo.setSpeciality(doctorEntity.getSpeciality());
					doctorPojo.setClinicName(doctorEntity.getClinicName());
					doctorPojo.setWorkHours(doctorEntity.getWorkHours());
					doctorPojo.setServiceId(doctorEntity.getMedicareService().getServiceId());
				}
			}
        }
        catch(HibernateException e)
     	 {
        	throw new ApplicationException(e.getMessage());
     	 }
     	 finally
     	 {
     		session.close();
     	 }
		 return value;
	}

	@Override
	public List<MedicareServicePojo> fetchAllMedicareServices() 
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		
        List<MedicareServicePojo> allMedicareServices=new ArrayList();
        
        try
        {
       	 List list = session.createQuery("from MedicareServiceEntity").list();

			for (int i = 0; i < list.size(); i++) 
			{
				MedicareServiceEntity medicareServiceEntity = (MedicareServiceEntity) list.get(i);
				MedicareServicePojo medicareServicePojo=new MedicareServicePojo();
				
				medicareServicePojo.setServiceId(medicareServiceEntity.getServiceId());
				medicareServicePojo.setName(medicareServiceEntity.getName());
				medicareServicePojo.setDescription(medicareServiceEntity.getDescription());
				medicareServicePojo.setAmount(medicareServiceEntity.getAmount());
				
				allMedicareServices.add(medicareServicePojo);
			}
        }catch(HibernateException e)
    	 {
    		e.printStackTrace();
    	 }
    	 finally
    	 {
    		session.close();
    	 }
        return allMedicareServices;
	}

	public ArrayList fetchDoctor() throws ApplicationException 
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		
        ArrayList doctorDetails=new ArrayList();
        try
        {
        	List list = session.createQuery("from DoctorEntity").list();
        	
        	for (int i = 0; i < list.size(); i++) 
        	{
        		DoctorEntity doctorEntity=(DoctorEntity)list.get(i);
        		DoctorPojo doctorPojo=new DoctorPojo();
        		
        		doctorPojo.setId(doctorEntity.getId());
        		doctorPojo.setFirstName(doctorEntity.getFirstName());
        		doctorPojo.setGender(doctorEntity.getGender());
        		doctorPojo.setNumber(doctorEntity.getNumber());
        		doctorPojo.setEmailId(doctorEntity.getEmailId());
        		doctorPojo.setDegree(doctorEntity.getDegree());
        		doctorPojo.setSpeciality(doctorEntity.getSpeciality());
        		doctorPojo.setWorkHours(doctorEntity.getWorkHours());
        		doctorPojo.setClinicName(doctorEntity.getClinicName());
        		doctorPojo.setServiceId(doctorEntity.getMedicareService().getServiceId());
        		
        		doctorDetails.add(doctorPojo);
        	}
        }
        catch(HibernateException e)
   	    {
   		    e.printStackTrace();
   	    }
   	    finally
   	    {
   		    session.close();
   	    }
        return doctorDetails;
	}

	public int updatePendingResult(TestResultPojo resultPojo) throws ApplicationException 
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		int update=0;
		
		try
		{
			TestResultEntity testResultEntity = session.load(TestResultEntity.class, resultPojo.getTestResultId());
			
			testResultEntity.setResultDate(resultPojo.getResultDate());
			testResultEntity.setActualValue(resultPojo.getActualValue());
			testResultEntity.setNormalValue(resultPojo.getNormalValue());
			testResultEntity.setComments(resultPojo.getComments());
			
			session.update(testResultEntity);
			tx.commit();
			
			update=1;
		}
		 catch(HibernateException e)
    	 {
    		if (tx!=null) 
    			tx.rollback();
    		throw new ApplicationException(e.getMessage());
    	 }
    	 finally
    	 {
    		session.close();
    	 }
		return update;
	}

	public ArrayList fetchPedingResult(int doctorId) throws ApplicationException 
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		
		ArrayList pendingTestResult = new ArrayList();
		
		try
		{
			List list = session.createQuery("from TestResultEntity tse where tse.doctorService.id="+doctorId +" and tse.actualValue=0 and tse.normalValue=0").list();
			
			for(int i=0;i<list.size();i++)
			{
				TestResultEntity testResultEntity = (TestResultEntity) list.get(i);
							
					TestResultPojo resultPojo=new TestResultPojo();
					resultPojo.setTestResultId(testResultEntity.getId());
					resultPojo.setCustomerId(testResultEntity.getCustomerService().getId());
					resultPojo.setCustomerName(testResultEntity.getCustomerService().getFirstName());
					resultPojo.setDoctorId(testResultEntity.getDoctorService().getId());
					resultPojo.setDoctorName(testResultEntity.getDoctorService().getFirstName());
					resultPojo.setServiceId(testResultEntity.getMedicareService().getServiceId());
					resultPojo.setServiceName(testResultEntity.getMedicareService().getName());
					resultPojo.setDate(testResultEntity.getDate());
					resultPojo.setResultDate(testResultEntity.getResultDate());
					resultPojo.setActualValue(testResultEntity.getActualValue());
					resultPojo.setNormalValue(testResultEntity.getNormalValue());
					resultPojo.setComments(testResultEntity.getComments());
					
					pendingTestResult.add(resultPojo);
			}
		}
		catch (HibernateException e) 
		{
			throw new ApplicationException(e.getMessage());
		} finally 
		{
			session.close();
		}
		return pendingTestResult;
	}

	public ArrayList fetchCompletedResult(int doctorId) throws ApplicationException 
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		
		ArrayList<TestResultPojo> completedTestResult = new ArrayList();
		
		try
		{
            List list = session.createQuery("from TestResultEntity tse where tse.doctorService.id="+doctorId +" and tse.actualValue<>0 and tse.normalValue<>0").list();
	
			for(int i=0;i<list.size();i++)
			{
				TestResultEntity testResultEntity = (TestResultEntity) list.get(i);
							
					TestResultPojo resultPojo=new TestResultPojo();
					resultPojo.setTestResultId(testResultEntity.getId());
					resultPojo.setCustomerId(testResultEntity.getCustomerService().getId());
					resultPojo.setCustomerName(testResultEntity.getCustomerService().getFirstName());
					resultPojo.setDoctorId(testResultEntity.getDoctorService().getId());
					resultPojo.setDoctorName(testResultEntity.getDoctorService().getFirstName());
					resultPojo.setServiceId(testResultEntity.getMedicareService().getServiceId());
					resultPojo.setServiceName(testResultEntity.getMedicareService().getName());
					resultPojo.setDate(testResultEntity.getDate());
					resultPojo.setResultDate(testResultEntity.getResultDate());
					resultPojo.setActualValue(testResultEntity.getActualValue());
					resultPojo.setNormalValue(testResultEntity.getNormalValue());
					resultPojo.setComments(testResultEntity.getComments());
					
					completedTestResult.add(resultPojo);
				
			}
		}
		catch (HibernateException e) 
		{
			throw new ApplicationException(e.getMessage());
		}
		finally 
		{
			session.close();
		}
		return completedTestResult;
	}

	@Override
	public int deletePendingResult(int testResultId) throws ApplicationException 
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		int delete=0;
		
		try
		{
			TestResultEntity testResultEntity = session.load(TestResultEntity.class, testResultId);
			
			session.delete(testResultEntity);
			tx.commit();
			
			delete=1;
		}
		catch(HibernateException e)
    	{
    		if (tx!=null) 
    			tx.rollback();
    		throw new ApplicationException(e.getMessage());
    	}
        finally
    	{
    		session.close();
    	}
		return delete;
	}

	public int updateMedicareServices(MedicareServicePojo medicareServicePojo) throws ApplicationException 
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		int update=0;
		
		try
		{
			MedicareServiceEntity medicareServiceEntity = session.load(MedicareServiceEntity.class,medicareServicePojo.getServiceId());
			
			medicareServiceEntity.setName(medicareServicePojo.getName());
			medicareServiceEntity.setDescription(medicareServicePojo.getDescription());
			medicareServiceEntity.setAmount(medicareServicePojo.getAmount());
			
			session.update(medicareServiceEntity);
			tx.commit();
			
			update=1;
		}
		catch(HibernateException e)
   	    {
   		 	if (tx!=null) 
   		 		tx.rollback();
   		 	throw new ApplicationException(e.getMessage());
   	    }
		finally
   	 	{
			session.close();
   	 	}
		return update;
	}

	public List<MedicareServicePojo> fetchMedicareServices(int serviceId) throws ApplicationException 
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		
		List<MedicareServicePojo> medicareServices=new ArrayList();
		
		try
		{
			MedicareServiceEntity medicareServiceEntity = session.load(MedicareServiceEntity.class,serviceId);
			MedicareServicePojo medicareServicePojo = new MedicareServicePojo();
			
			medicareServicePojo.setServiceId(medicareServiceEntity.getServiceId());
			medicareServicePojo.setName(medicareServiceEntity.getName());
			medicareServicePojo.setDescription(medicareServiceEntity.getDescription());
			medicareServicePojo.setAmount(medicareServiceEntity.getAmount());
			
			medicareServices.add(medicareServicePojo);
		}
		catch (HibernateException e) 
		{
			throw new ApplicationException(e.getMessage());
		}
		finally 
		{
			session.close();
		}
		return medicareServices;
	}
}
