package com.medicare.dao;

import java.awt.geom.RectangularShape;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.medicare.entity.CustomerEntity;
import com.medicare.entity.DoctorEntity;
import com.medicare.entity.MedicareServiceEntity;
import com.medicare.entity.TestResultEntity;
import com.medicare.pojo.CustomerPojo;
import com.medicare.pojo.MedicareServicePojo;
import com.medicare.pojo.TestResultPojo;

@Repository
public class CustomerDaoImpl implements CustomerDao 
{
	public int addCustomer(CustomerPojo pojo) throws ApplicationException 
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		int rowAffected = 0;
		
		try
		{
			CustomerEntity customer = new CustomerEntity();
			
			customer.setId(pojo.getId());
			customer.setFirstName(pojo.getFirstName());
			customer.setLastName(pojo.getLastName());
			customer.setAge(pojo.getAge());
			customer.setGender(pojo.getGender());
			customer.setDob(pojo.getDob());
			customer.setNumber(pojo.getNumber());
			customer.setAltNumber(pojo.getAltNumber());
			customer.setEmailId(pojo.getEmailId());
			customer.setPassword(pojo.getPassword());
			customer.setAddress1(pojo.getAddress1());
			customer.setAddress2(pojo.getAddress2());
			customer.setCity(pojo.getCity());
			customer.setState(pojo.getState());
			customer.setZipCode(pojo.getZipCode());
			session.save(customer);
			rowAffected = 1;
			tx.commit();
		}
		catch (HibernateException e)
		{
			if (tx != null)
				tx.rollback();
			throw new ApplicationException(e.getMessage());
		}
		finally 
		{
			session.close();
		}
		return rowAffected;
	}

	public int loginCustomer(CustomerPojo pojo) throws ApplicationException
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		
		int value = 0;
		try 
		{
			List list = session.createQuery("from CustomerEntity").list();

			for (int i = 0; i < list.size(); i++) 
			{
				CustomerEntity customer = (CustomerEntity) list.get(i);
				
				if (pojo.getFirstName().equals(customer.getFirstName())
						&& (pojo.getPassword().equals(customer.getPassword()))) 
				{
					value = 1;
					pojo.setId(customer.getId());
					pojo.setLastName(customer.getLastName());
					pojo.setGender(customer.getGender());
					pojo.setAge(customer.getAge());
					pojo.setDob(customer.getDob());
					pojo.setAddress1(customer.getAddress1());
					pojo.setAddress2(customer.getAddress2());
					pojo.setEmailId(customer.getEmailId());
					pojo.setCity(customer.getCity());
					pojo.setState(customer.getState());
					pojo.setNumber(customer.getNumber());
					pojo.setAltNumber(customer.getAltNumber());
					pojo.setZipCode(customer.getZipCode());
				}
			}
		} 
		catch (HibernateException e) 
		{
			throw new ApplicationException(e.getMessage());
		} 
		finally 
		{
			session.close();
		}
		return value;
	}

	public ArrayList fetchMedicare() throws ApplicationException 
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		
		ArrayList medicareDetails = new ArrayList();
		
		try 
		{
			List list = session.createQuery("from MedicareServiceEntity").list();
			for (int i = 0; i < list.size(); i++) {
				MedicareServiceEntity medicareServiceEntity = (MedicareServiceEntity) list.get(i);
				MedicareServicePojo medicareServicePojo = new MedicareServicePojo();
				medicareServicePojo.setServiceId(medicareServiceEntity.getServiceId());
				medicareServicePojo.setName(medicareServiceEntity.getName());
				medicareServicePojo.setDescription(medicareServiceEntity.getDescription());
				medicareServicePojo.setAmount(medicareServiceEntity.getAmount());
				medicareDetails.add(medicareServicePojo);
			}
		} 
		catch (HibernateException e) 
		{
			throw new ApplicationException(e.getMessage());
		} finally
		{
			session.close();
		}
		return medicareDetails;
	}

	public int insertRequest(TestResultPojo resultPojo) throws ApplicationException {
		
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		int testResultId = 0;
		
		
		try {
			
			TestResultEntity resultEntity = new TestResultEntity();
			
			MedicareServiceEntity medicareEntity = session.load(MedicareServiceEntity.class, resultPojo.getServiceId());
			DoctorEntity doctorEntity = session.load(DoctorEntity.class, medicareEntity.getDoctorEntityService().getId());
			CustomerEntity customerEntity = session.load(CustomerEntity.class, resultPojo.getCustomerId());
			
			resultEntity.setCustomerService(customerEntity);
			resultEntity.setMedicareService(medicareEntity);
			resultEntity.setDoctorService(doctorEntity);
			
			resultEntity.setDate(resultPojo.getDate());
			
			session.save(resultEntity);
			//session.flush();
			tx.commit();
			
			
			System.out.println("id:"+resultEntity.getId());
			testResultId = 1;
			
		} catch (HibernateException e) {
			throw new ApplicationException(e.getMessage());
		} finally {
			session.close();
		}
		return testResultId;
	}

	public ArrayList fetchPendingResult(int customerId) throws ApplicationException 
	{
		
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		
		ArrayList pendingTestResult = new ArrayList();
				
		try
		{
			List list = session.createQuery("from TestResultEntity tse where tse.customerService.id="+customerId +" and tse.actualValue=0 and tse.normalValue=0").list();
			
			for(int i=0;i<list.size();i++)
			{
				TestResultEntity testResultEntity = (TestResultEntity) list.get(i);
							
					TestResultPojo resultPojo=new TestResultPojo();
					resultPojo.setTestResultId(testResultEntity.getId());
					resultPojo.setCustomerId(testResultEntity.getCustomerService().getId());
					resultPojo.setCustomerName(testResultEntity.getCustomerService().getFirstName());
					resultPojo.setDoctorId(testResultEntity.getDoctorService().getId());
					resultPojo.setDoctorName(testResultEntity.getDoctorService().getFirstName());
					resultPojo.setServiceId(testResultEntity.getMedicareService().getServiceId());
					resultPojo.setServiceName(testResultEntity.getMedicareService().getName());
					resultPojo.setDate(testResultEntity.getDate());
					resultPojo.setResultDate("pending");
					
					pendingTestResult.add(resultPojo);
				
			}
		}
		catch (HibernateException e) 
		{
			throw new ApplicationException(e.getMessage());
		} finally 
		{
			session.close();
		}
		return pendingTestResult;
	}

	public ArrayList fetchCompletedResult(int customerId) throws ApplicationException 
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		
		ArrayList<TestResultPojo> completedTestResult = new ArrayList();
				
		try
		{
			List list = session.createQuery("from TestResultEntity tse where tse.customerService.id="+customerId +" and tse.actualValue<>0 and tse.normalValue<>0").list();
			
			System.out.println(list.size());
			for(int i=0;i<list.size();i++)
			{
				TestResultEntity testResultEntity = (TestResultEntity) list.get(i);
							
					TestResultPojo resultPojo=new TestResultPojo();
					resultPojo.setTestResultId(testResultEntity.getId());
					resultPojo.setCustomerId(testResultEntity.getCustomerService().getId());
					resultPojo.setCustomerName(testResultEntity.getCustomerService().getFirstName());
					resultPojo.setDoctorId(testResultEntity.getDoctorService().getId());
					resultPojo.setDoctorName(testResultEntity.getDoctorService().getFirstName());
					resultPojo.setServiceId(testResultEntity.getMedicareService().getServiceId());
					resultPojo.setServiceName(testResultEntity.getMedicareService().getName());
					resultPojo.setDate(testResultEntity.getDate());
					resultPojo.setResultDate(testResultEntity.getResultDate());
					resultPojo.setActualValue(testResultEntity.getActualValue());
					resultPojo.setNormalValue(testResultEntity.getNormalValue());
					resultPojo.setComments(testResultEntity.getComments());
					
					completedTestResult.add(resultPojo);
				
			}
		}
		catch (HibernateException e) 
		{
			throw new ApplicationException(e.getMessage());
		}
		finally 
		{
			session.close();
		}
		return completedTestResult;
	}
}
