package com.medicare.dao;

import java.util.List;
import org.hibernate.HibernateException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.medicare.entity.AdminEntity;
import com.medicare.pojo.AdminPojo;

@Repository
public class AdminDaoImpl implements AdminDao
{
    public int addAdmin(AdminPojo pojo) throws ApplicationException

     {
    	 SessionFactory sf= null;
         Session session =null;
         sf=HibernateUtil.getSessionFactory();
         session=sf.openSession();
         int rowAffected=0;
         Transaction tx = null;
         try
         {
        	 tx = session.beginTransaction();
        	 AdminEntity admin=new AdminEntity();
        	 admin.setId(pojo.getId());
	    	 admin.setFirstName(pojo.getFirstName());
	    	 admin.setLastName(pojo.getLastName());
	    	 admin.setAge(pojo.getAge());
	    	 admin.setGender(pojo.getGender());
	    	 admin.setDob(pojo.getDob());
	    	 admin.setNumber(pojo.getNumber());
	    	 admin.setAltNumber(pojo.getAltNumber());
	    	 admin.setEmailId(pojo.getEmailId());
	    	 admin.setPassword(pojo.getPassword());
        	 session.save(admin);
        	 rowAffected=1;
     		 tx.commit();
         }
         catch(HibernateException e)
      	 {
      		if (tx!=null) 
      			tx.rollback();
      		throw new ApplicationException(e.getMessage());
      	 }
      	 finally
      	 {
      		session.close();
      	 }
    	 return rowAffected;
     }


	public int loginAdmin(AdminPojo pojo) throws ApplicationException
	{
		SessionFactory sf= null;
        Session session =null;
        sf=HibernateUtil.getSessionFactory();
        session=sf.openSession();
        int value=0;
        try
        {
       	 List list = session.createQuery("from AdminEntity").list();

			for (int i = 0; i < list.size(); i++) 
			{
				AdminEntity admin = (AdminEntity) list.get(i);
				if(pojo.getFirstName().equals(admin.getFirstName())&&(pojo.getPassword().equals(admin.getPassword())))
				{
					value=1;
				}
			}
        }
        catch(HibernateException e)
     	 {
        	throw new ApplicationException(e.getMessage());
     	 }
     	 finally
     	 {
     		session.close();
     	 }
		 return value;
	}
}
