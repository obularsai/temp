package com.medicare.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.medicare.dao.ApplicationException;
import com.medicare.pojo.DoctorPojo;
import com.medicare.pojo.MedicareServicePojo;
import com.medicare.pojo.TestResultPojo;
import com.medicare.service.DoctorService;

@Controller
public class DoctorController 
{
	public static Logger logger = Logger.getLogger("MedicareProject");
	@Autowired
    DoctorService doctorService;
    
    @RequestMapping("/")
	public ModelAndView login() 
	{		
		return new ModelAndView("Home");
	}
    
    @RequestMapping("/doctorLogin")
	public ModelAndView doctorLogin() 
	{		
		return new ModelAndView("DoctorLogin");
	}
	
	@RequestMapping("/doctorRegistration")
	public ModelAndView doctorRegistration() 
	{	
		List<MedicareServicePojo> allMedicareServices=null;
		try
		{
		    allMedicareServices = doctorService.fetchAllMedicareServices();
		}
	    catch(ApplicationException e)
	    {
				logger.error(e);
	    }
		ModelAndView mav=new ModelAndView("DoctorRegistration");
	    mav.addObject("allMedicareServices",allMedicareServices);
	    return mav; 
	}
	
	@RequestMapping("/doctorLoginProcess")
	public ModelAndView doctorLoginProcess(@ModelAttribute("command") DoctorPojo doctorPojo, BindingResult result,HttpServletRequest request) 
	{		
		HttpSession session = request.getSession();
		ModelAndView mav=null;
		
		System.out.println("doctorLoginProcess:"+doctorPojo.getFirstName());
		int login=0;
		ArrayList pendingTestResult = null;
		ArrayList completedTestResult = null;
		List<MedicareServicePojo> medicareServices=null;
		try
		{
		   login = doctorService.loginDoctor(doctorPojo);
		   if (login==1)
		   {
			    session.setAttribute("doctor",doctorPojo);
			    int doctorId = ((DoctorPojo) session.getAttribute("doctor")).getId();
			    int serviceId = ((DoctorPojo) session.getAttribute("doctor")).getServiceId();
			    
			    pendingTestResult = doctorService.fetchPendingResult(doctorId);
			    System.out.println("pendingTestResult:"+pendingTestResult.size());
			    
				completedTestResult = doctorService.fetchCompletedResult(doctorId);
				System.out.println("completedTestResult:"+completedTestResult.size());
				
				medicareServices = doctorService.fetchMedicareServices(serviceId);
				System.out.println("medicareServices:"+medicareServices);
				
				System.out.println("doctorId:"+ doctorId);
				System.out.println("serviceId:"+serviceId);
				
				mav = new ModelAndView("Doctor");
				
				mav.addObject("pendingTestResult",pendingTestResult);
				mav.addObject("completedTestResult",completedTestResult);
				mav.addObject("medicareServices",medicareServices);
				
				System.out.println("mav:"+mav.getViewName());
		   } 
		   else
		   {
				mav = new ModelAndView("Error");
		   }
		}
		catch(ApplicationException e)
		{
			logger.error(e);
			mav = new ModelAndView("Error");
		}
		return mav;
	}
	
	@RequestMapping("/registerDoctor")
	public ModelAndView registerDoctor(@ModelAttribute("command") DoctorPojo doctorPojo, BindingResult result) 
	{			
		int register=0;
		ModelAndView mav=null;
		try
		{
		    register = doctorService.addDoctor(doctorPojo);
		    if(register == 1)
			{
				mav = new ModelAndView("Success");
			} 
			else
			{
				mav = new ModelAndView("ErrorRegistration");
			}
		}
		catch(ApplicationException e)
		{
			logger.error(e);
		}
		return mav;
	}
	
	@RequestMapping("/logoutDoctor")
	public ModelAndView logoutDoctor(HttpSession session)
	{
	   ModelAndView mav=null;
	   
	   session.removeAttribute("doctor");
	   session.invalidate();
	   
	   mav = new ModelAndView("Home");
	   return mav;
	}
	
	@RequestMapping("/updatePendingResult")
	public ModelAndView updatePendingResult(@RequestParam int testResultId,@RequestParam String resultDate , @RequestParam int actualValue , @RequestParam int normalValue , @RequestParam String comments , HttpSession session)
	{ 
		ModelAndView mav = null;
		
		int update=0;
		ArrayList pendingTestResult = null;
		
		TestResultPojo resultPojo = new TestResultPojo();
		
	    resultPojo.setTestResultId(testResultId);
	    resultPojo.setResultDate(resultDate);
	    resultPojo.setActualValue(actualValue);
	    resultPojo.setNormalValue(normalValue);
	    resultPojo.setComments(comments);
	    
	    try
	    {
	    	update = doctorService.updatePendingResult(resultPojo);
	    	if(update != 0)
	    	{
	    		int doctorId = ((DoctorPojo) session.getAttribute("doctor")).getId(); 
	    		
	    		pendingTestResult = doctorService.fetchPendingResult(doctorId);
	    		mav = new ModelAndView("Doctor");
	    		
	    		mav.addObject("pendingTestResult",pendingTestResult);
	    	}
	    	else
	    	{
	    		System.out.println("Result not updated");
	    	}
	    }
	    catch(ApplicationException e)
	    {
				logger.error(e);
	    }
	    return mav;
	}
	
	@RequestMapping("/deletePendingResult")
	public ModelAndView deletePendingResult(@RequestParam int testResultId,HttpSession session)
	{
		ModelAndView mav = null;
		
		int delete=0;
		ArrayList pendingTestResult = null;
		
		try
		{
			delete = doctorService.deletePendingResult(testResultId);
			if(delete != 0)
			{
                int doctorId = ((DoctorPojo) session.getAttribute("doctor")).getId(); 
	    		
	    		pendingTestResult = doctorService.fetchPendingResult(doctorId);
	    		mav = new ModelAndView("Doctor");
	    		
	    		mav.addObject("pendingTestResult",pendingTestResult);
			}
			else
			{
				System.out.println("Result not deleted");
			}
		}
		catch(ApplicationException e)
	    {
				logger.error(e);
	    }
		
		return mav;
	}
	
	@RequestMapping("/updateMedicareServices")
	public ModelAndView updateMedicareServices(@ModelAttribute("command") MedicareServicePojo medicareServicePojo, HttpSession session)
	{
		ModelAndView mav = null;
		
		int update=0;
		List<MedicareServicePojo> medicareServices=null;
	
		try
		{
			 update=doctorService.updateMedicareServices(medicareServicePojo);
			 if(update != 0)
			 {
				 int serviceId = medicareServicePojo.getServiceId();
				 
				 medicareServices = doctorService.fetchMedicareServices(serviceId);
				 mav = new ModelAndView("Doctor");
		    		
		    	 mav.addObject("medicareServices",medicareServices);
			 }
			 else
			 {
				 System.out.println("Update not successfull");
			 }
		}
		catch(ApplicationException e)
	    {
				logger.error(e);
	    }
		
		return mav;
	}
}
