package com.medicare.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.medicare.dao.ApplicationException;
import com.medicare.pojo.AdminPojo;
import com.medicare.service.AdminService;

@Controller
public class AdminController 
{
	public static Logger logger = Logger.getLogger("MedicareProject");
	@Autowired
	AdminService adminService;
	
	@RequestMapping("/")
	public ModelAndView login() 
	{		
		return new ModelAndView("Home");
	}
	
	@RequestMapping("/adminLogin")
	public ModelAndView adminLogin() 
	{		
		return new ModelAndView("AdminLogin");
	}
	
	@RequestMapping("/adminRegistration")
	public ModelAndView adminRegistration() 
	{		
		return new ModelAndView("AdminRegistration");
	}
	
	@RequestMapping("/adminLoginProcess")
	public ModelAndView adminLoginProcess(@ModelAttribute("command") AdminPojo adminPojo, BindingResult result) 
	{		
		int login=0;	
		try
		{
		 login = adminService.loginAdmin(adminPojo);
		}
		catch(ApplicationException e)
		{
			logger.error(e);
		}
		if (login==1)
		 {
			return new ModelAndView("Admin");
		 } 
		 else
		 {
			return new ModelAndView("Error");
		 }
	}
	
	@RequestMapping("/registerAdmin")
	public ModelAndView registerAdmin(@ModelAttribute("command") AdminPojo adminPojo, BindingResult result) 
	{		
		int login=0;
		try
		{
		login = adminService.addAdmin(adminPojo);
		}
		catch(ApplicationException e)
		{
			logger.error(e);
		}
		if (login==1)
		{
			return new ModelAndView("Home");
		} 
		else
		{
			return new ModelAndView("ErrorRegistration");
		}
	}
}
