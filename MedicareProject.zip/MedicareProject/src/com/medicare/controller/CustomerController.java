package com.medicare.controller;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.medicare.dao.ApplicationException;
import com.medicare.entity.MedicareServiceEntity;
import com.medicare.pojo.CustomerPojo;
import com.medicare.pojo.TestResultPojo;
import com.medicare.service.CustomerService;
import com.medicare.service.DoctorService;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;

@Controller
public class CustomerController 
{
	public static Logger logger = Logger.getLogger("MedicareProject");
	@Autowired
	CustomerService customerService;
	
	@Autowired
	DoctorService doctorService;
	
	@RequestMapping("/")
	public ModelAndView login() 
	{		
		return new ModelAndView("Home");
	}
	
	@RequestMapping("/customerLogin")
	public ModelAndView customerLogin() 
	{		
		return new ModelAndView("CustomerLogin");
	}
	
	@RequestMapping("/customerRegistration")
	public ModelAndView customerRegistration() 
	{		
		return new ModelAndView("CustomerRegistration");
	}
	
	@RequestMapping("/customerLoginProcess")
	public ModelAndView customerLoginProcess(@ModelAttribute("command") CustomerPojo pojo, BindingResult result,HttpServletRequest request) 
	{		
		HttpSession session = request.getSession();
		int login=0;
		ModelAndView mav=null;
		ArrayList medicareDetails = null;
		ArrayList doctorDetails=null;
		ArrayList pendingTestResult=null;
		ArrayList completedTestResult=null;
		try 
		{
			login = customerService.loginCustomer(pojo);
		   
			if (login==1)
			{
				session.setAttribute("customer",pojo);
								
				//TestResultPojo resultPojo = new TestResultPojo();
				int customerId = ((CustomerPojo)session.getAttribute("customer")).getId();
								
				medicareDetails=customerService.fetchMedicare();
				doctorDetails=doctorService.fetchDoctor();
				pendingTestResult=customerService.fetchPendingResult(customerId);
				completedTestResult=customerService.fetchCompletedResult(customerId);
		
				mav = new ModelAndView("Customer");
				
				mav.addObject("medicareDetail",medicareDetails);
				mav.addObject("doctorDetail",doctorDetails);
				mav.addObject("pendingTestResult",pendingTestResult);
				mav.addObject("completedTestResult",completedTestResult);
			}
			else
			{ 
				mav = new ModelAndView("Error");
			}
				
		}
		catch(ApplicationException e)
		{
			logger.info(e.getMessage());
			mav = new ModelAndView("ApplicationError");
	    }
		
		return mav;
	}
	
	@RequestMapping("/registerCustomer")
	public ModelAndView registerCustomer(@ModelAttribute("command") CustomerPojo pojo, BindingResult result) 
	{		
		int register=0;
		ModelAndView mav=null;
		try
		{
		     register = customerService.addCustomer(pojo);
		     if (register==1)
			 {
				mav = new ModelAndView("Home");
			 } 
			 else
			 {
				mav = new ModelAndView("ErrorRegistration");
			 }
		}
		catch(ApplicationException e)
		{
			logger.error(e);
		}
		return mav;
	}
	
	@RequestMapping("/logoutCustomer")
	public ModelAndView logoutCustomer(HttpSession session)
	{
		ModelAndView mav=null;
		
		session.removeAttribute("customer");
	    session.invalidate();
	    
	    mav = new ModelAndView("Home");
		return mav;
	}
	
	@RequestMapping("/testResultProcess")
	public ModelAndView testResultProcess(@RequestParam int serviceId, @RequestParam String date, HttpSession session)
	{
	     int request=0;
	     ModelAndView mav=null;
	     
	     TestResultPojo resultPojo = new TestResultPojo();
	     	     
	     resultPojo.setServiceId(serviceId);
	     resultPojo.setDate(date);
	     resultPojo.setCustomerId(((CustomerPojo)session.getAttribute("customer")).getId());
	     
	     System.out.println("customer id:" +((CustomerPojo)session.getAttribute("customer")).getId());
	     
	     try
	     {
	        	 request= customerService.insertRequest(resultPojo);
	        	 if (request!=0)
	    		 {
	    			mav = new ModelAndView("Home");
	    		 } 
	    	     else
	    		 {
	    	    	 mav =  new ModelAndView("ErrorRegistration");
	    		 }
	     }
	     catch(ApplicationException e)
		 {
				logger.error(e);
		 }
	     return mav;
	}
}
