package com.smgmt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.smgmt.bean.Student;
import com.smgmt.dao.DBUtil;

public class StudentDao {
	public static int insertStudent(Student s) {
		int i = 0;
		try {
			Connection con = DBUtil.createConnection();
			PreparedStatement ps = con.prepareStatement("insert into student (name,department,college) values(?,?,?)");
			ps.setString(1, s.getName());
			ps.setString(2, s.getDepartment());
			ps.setString(3, s.getCollege());
			i = ps.executeUpdate();
			if (i != 0) {
				i = 1;
			}
		} catch (Exception e) {
			e.getMessage();
		}
		return i;
	}

	public static int deleteStudent(Student s) {
		int i = 0;
		try {
			Connection con = DBUtil.createConnection();
			PreparedStatement ps = con.prepareStatement("delete from student where id=?");
			ps.setInt(1, s.getId());

			i = ps.executeUpdate();
			if (i != 0)
				i = 1;
		} catch (Exception e) {
			e.getMessage();
		}
		return i;
	}

	public static List<Student> fetchStudents() {
		List<Student> studList = new ArrayList<Student>();
		try {
			Connection con = DBUtil.createConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from student");

			while (rs.next()) {
				Student s = new Student();
				s.setId(rs.getInt(1));
				s.setName(rs.getString(2));
				s.setDepartment(rs.getString(3));
				s.setCollege(rs.getString(4));

				studList.add(s);
			}
		} catch (Exception e) {
			e.getMessage();
		}
		return studList;
	}
	
	public static int updateStudent(Student s) {
		int i = 0;
		try {
			Connection con = DBUtil.createConnection();
			PreparedStatement ps = con.prepareStatement("UPDATE student SET name=?,department=?,college=? WHERE id=?;");
			ps.setString(1, s.getName());
			ps.setString(2, s.getDepartment());
			ps.setString(3, s.getCollege());
			ps.setInt(4, s.getId());
			i = ps.executeUpdate();
			if (i != 0) {
				i = 1;
			}
		} catch (Exception e) {
			e.getMessage();
		}
		return i;
	}
	
	public static Student fetchStudent(int id) {
		Student s = new Student();
		try {
			Connection con = DBUtil.createConnection();
			Statement ps = con.createStatement();
			ResultSet rs = ps.executeQuery("select * from student where id="+ id);
			
			while (rs.next()) {
				s.setId(rs.getInt(1));
				s.setName(rs.getString(2));
				s.setDepartment(rs.getString(3));
				s.setCollege(rs.getString(4));
			}
		} catch (Exception e) {
			e.getMessage();
		}
		return s;
	}
}
