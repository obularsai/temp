package com.smgmt.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.smgmt.bean.Student;
import com.smgmt.dao.StudentDao;


/**
 * Servlet implementation class InsertServlet
 */
@WebServlet("/InsertServlet")
public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int insertStatus = 0;
		String name=request.getParameter("name");
		String department=request.getParameter("department");
		String college=request.getParameter("college");
		
     	Student s = new Student();
     	s.setName(name);
     	s.setDepartment(department);
     	s.setCollege(college);
     	
     	response.setContentType("text/html");
     	
     	insertStatus = StudentDao.insertStudent(s);
     	if(insertStatus == 1){
     		RequestDispatcher rd=request.getRequestDispatcher("StudentInserted.html");
		    rd.forward(request, response);
     	} else {
     		RequestDispatcher rd=request.getRequestDispatcher("Failed.html");
		    rd.forward(request, response);
     	}
	}
}
