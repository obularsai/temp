package com.retail.dao;

import java.util.ArrayList;
import java.util.List;

import com.retail.model.Retailer;

public class RetailDao {

	static List<Retailer> retailerList;
	static List<Retailer> anotherList = new ArrayList<>();

	public List<Retailer> initializeRetailers() {

		retailerList = new ArrayList<>();

		retailerList.add(new Retailer(1, "Dummy1", "Iowa", "US", "987352", "9876543210", "dummy1@gmail.com"));
		retailerList.add(new Retailer(2, "Dummy2", "Ohio", "US", "654321", "9876543210", "dummy2@gmail.com"));
		retailerList.add(new Retailer(3, "Dummy3", "Wisconsin", "US", "987456", "9876543210", "dummy3@gmail.com"));
		retailerList.add(new Retailer(4, "Dummy4", "Texas", "US", "657513", "9876543210", "dummy4@gmail.com"));
		retailerList.add(new Retailer(5, "Dummy5", "Missouri", "US", "325733", "9876543210", "dummy5@gmail.com"));

		return retailerList;
	}

	public Retailer searchRetailerById(int rid) {

		Retailer retailer = new Retailer();
		for (int i = 0; i < retailerList.size(); i++) {
			if (retailerList.get(i).getId() == rid) {
				retailer = retailerList.get(i);
			}
		}
		return retailer;
	}

	public List<Retailer> addAnotherList(Retailer r) {
		anotherList.add(r);
		return anotherList;
	}

	public List<Retailer> getAnotherList() {
		return anotherList;
	}
}
