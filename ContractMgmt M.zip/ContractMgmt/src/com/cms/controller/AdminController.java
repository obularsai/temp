package com.cms.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.http.HttpSession;

import org.hibernate.mapping.Array;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cms.bean.AdminBean;
import com.cms.bean.ContractBean;
import com.cms.bean.SupplierBean;
import com.cms.exception.ApplicationException;
import com.cms.service.AdminService;
import com.cms.service.ContractService;
import com.cms.service.SupplierService;

@Controller
public class AdminController {

	@Autowired
	AdminService adminService;

	@Autowired
	SupplierService supplierService;

	@Autowired
	ContractService contractService;

	static Logger log = Logger.getLogger("ContractMgmt");

	@RequestMapping(value = "/addAdmin", method = RequestMethod.POST)
	public ModelAndView saveAdmin(@ModelAttribute("command") AdminBean adminBean, BindingResult result,
			HttpSession session) {
		if (session.getAttribute("adminBean") != null) {
			try {
				adminService.addAdmin(adminBean);

			} catch (ApplicationException ae) {
				log.info(ae.getMessage());
				return new ModelAndView("applicationError");
			}
			return new ModelAndView("index", "successMessage1", "SuccessFully Admin Registered!!!");

		} else {
			return new ModelAndView("index");
		}
	}

	@RequestMapping(value = "/loginAdmin", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView loginAdmin(@ModelAttribute("command") AdminBean adminBean1, BindingResult result,
			HttpSession session) {
		if (adminBean1.getFirstName() != null) {
			AdminBean adminBean = null;
			// List supplierList = new ArrayList<SupplierBean>();
			List contractList = new ArrayList<ContractBean>();
			// List contractList1 = new ArrayList<>();
			Map<String, Object> model = new HashMap<String, Object>();
			try {
				adminBean = adminService.loginAdminCheck(adminBean1.getFirstName());
				session.setAttribute("adminBean", adminBean);
				if (adminBean1.getPassword().equals(adminBean.getPassword())
						&& adminBean1.getFirstName().equals(adminBean.getFirstName())) {
					contractList = contractService.fetchAllContracts();
					model.put("contractList", contractList);
					model.put("AdminName", adminBean1.getFirstName());
					return new ModelAndView("admin", model);
				} else
					return new ModelAndView("index", "message1", "Invalid Username or Password");
			} catch (ApplicationException ae) {
				log.info(ae.getMessage());
				return new ModelAndView("applicationError");
			}
		} else {
			return new ModelAndView("index");
		}
	}

	/*
	 * @RequestMapping(value = "/fetchContractForAdmin") public ModelAndView
	 * fetchContractForAdmin() throws ApplicationException{ //SupplierBean
	 * supplierBean = new SupplierBean(); //supplierBean =
	 * supplierService.fetchSupplier(contractBean.getSupplierId()); try {
	 * contractBean =
	 * contractService.fetchContract(contractBean.getContractId()); return new
	 * ModelAndView("admin", "contractList", contractBean); } catch
	 * (ApplicationException ae) { log.info(ae.getMessage()); return new
	 * ModelAndView("applicationError"); } }
	 */
	// private AdminBean prepareModel(AdminBean adminBean) {
	// adminBean.setFirstName(adminBean.getFirstName());
	// adminBean.setLastName(adminBean.getLastName());
	// adminBean.setAge(adminBean.getAge());
	// adminBean.setGender(adminBean.getGender());
	// adminBean.setDob(adminBean.getDob());
	// adminBean.setContactNumber(adminBean.getContactNumber());
	// adminBean.setAltContactNumber(adminBean.getAltContactNumber());
	// adminBean.setEmailId(adminBean.getEmailId());
	//
	// return adminBean;
	// }

}
