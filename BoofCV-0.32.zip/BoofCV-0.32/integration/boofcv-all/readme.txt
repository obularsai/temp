The purpose of this package is to create an easy way to include ALL of BoofCV.  This includes packages in
integration