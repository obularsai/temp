sudo apt-get install openjfx

need to manually add jars to JDK in IntelliJ

http://packages.ubuntu.com/xenial/amd64/openjfx/filelist
