Integration for Webcam Capture, a library which provides a really simple webcam API allowing you to use your build-in,
external (USB-connected) webcams or IP / network cameras directly from Java code.

http://webcam-capture.sarxos.pl/

To build this sub-project's jar type "gradle createLibraryDirectory" and look in boofcv/libraries for the compiled jar.