The purpose of this package is to create an easy way to include all of BoofCV.  It is dependent on all the packages
in main.