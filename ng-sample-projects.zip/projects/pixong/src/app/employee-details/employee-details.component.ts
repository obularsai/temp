import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { EmployeeDataService } from '../employee-data.service';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {

  public employees;
  public e: Employee;
  @Output()
  employeeEmitter = new EventEmitter<Employee>();

  constructor(private employeeDataService: EmployeeDataService) {

  }

  ngOnInit() {
    this.employeeDataService.getEmployeeData().subscribe(data => this.employees = data);
  }
}
