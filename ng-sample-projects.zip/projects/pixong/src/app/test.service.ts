import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TestService {

  private url = "https://jsonplaceholder.typicode.com/posts";
  private url_photo = "https://jsonplaceholder.typicode.com/photos"
  constructor(private http: HttpClient) { }

  getPosts(): Observable<Post[]> {
    return this.http.get<Post[]>(this.url);
  }
  getPhotos(): Observable<Photos[]> {
    return this.http.get<Photos[]>(this.url_photo);
  }

}
