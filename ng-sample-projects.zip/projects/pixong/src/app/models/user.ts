export class User {

    constructor(
        public uname: string,
        public email: string,
        public phone: number,
        public topic: string,
        public gender: string,
        public subscribe: boolean
    ) {

    }

    

}