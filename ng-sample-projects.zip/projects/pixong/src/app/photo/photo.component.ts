import { Component, OnInit } from '@angular/core';
import { TestService } from '../test.service';

@Component({
  selector: 'app-photo',
  templateUrl: './photo.component.html',
  styleUrls: ['./photo.component.css']
})
export class PhotoComponent implements OnInit {

  public albums;

  constructor(private testService: TestService) { }

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.testService.getPhotos().subscribe(
      (data) => this.albums = data
    );
  }

}
