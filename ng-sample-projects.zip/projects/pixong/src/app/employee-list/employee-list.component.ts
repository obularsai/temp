import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  employees = [];

  constructor() {
    this.employees = [
      { name: 'Sai', empId: 'emp001', dob: '12/25/1983', gender: 'male' },
      { name: 'Priyanka', empId: 'emp002', dob: '12/30/1983', gender: 'female' },
      { name: 'Sundar', empId: 'emp003', dob: '12/16/1983', gender: 'male' },
      { name: 'Stacy', empId: 'emp004', dob: '12/1/1983', gender: 'female' },
      { name: 'Suzan', empId: 'emp005', dob: '12/9/1983', gender: 'female' }
    ]
  }

  ngOnInit() {
  }

  getTotalEmployeeCount(): number {
    return this.employees.length;
  }
  getTotalMaleEmployeeCount(): number {
    return this.employees.filter(e => e.gender == 'male').length;
  }
  getTotalFemaleEmployeeCount(): number {
    return this.employees.filter(e => e.gender == 'female').length;
  }
}
