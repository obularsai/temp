import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test2',
  template: `
  
  <img [src]="imagePath" height="100" width="100"/>
  <br>
  <img src="{{ imagePath }}" height="100" width="100"/>
  <br>
  <button>1</button>
  <button disabled="{{isDisabled}}">2</button>
  <button [disabled]="isDisabled">3</button>
  <br>
  <p>{{ imagePath + imageName }}</p>
  <img src="{{ imagePath + imageName }}" height="100" width="100" alt="link broken due to improper Interpolation"/>
  
  `,
  styleUrls: ['./test2.component.css']
})
export class Test2Component implements OnInit {

  public imagePath = "https://getbootstrap.com/docs/4.0/assets/brand/bootstrap-solid.svg";
  public imageName = "dummy";
  public isDisabled = true;
  constructor() { }

  ngOnInit() {
  }

}
