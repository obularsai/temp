import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';

@Component({
  selector: 'app-test-form',
  templateUrl: './test-form.component.html',
  styleUrls: ['./test-form.component.css']
})
export class TestFormComponent implements OnInit {

  public userModel = new User('Mark', 'm@gmail.com', 9999999999, 'HTML', 'male', true);

  public topics = ['HTML', 'CSS', 'JS'];

  constructor() { }

  ngOnInit() {
  }

}