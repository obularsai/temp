import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test3',
  template: `
  
  <button (click) ="onButtonClick($event)">Button</button>
  <br>
  <div (dblclick) = "onButtonClick($event)" style='padding:20px; height: 100px; width: 100px;border: 1px solid red'>H</div>
  
  <h1 class="text-danger">Some heading</h1>
  <h1 [class]="textSuccess">Next heading with binding</h1>
  <h1 [class.text-success]="applyClass">Next heading 1</h1>
  <h1 [class.text-success]=true>Next heading 2</h1>
  <h1 [ngClass]="message">Next heading with binding</h1>

  <h2 style="color: red">Heading Level 2</h2>
  <h2 [style.color] = "'orange'">Heading Level 2</h2>
  <h2 [style.color] = "hasError ? 'green' : 'orange'">Heading Level 2</h2>
  <h2 [ngStyle] = "titleStyle">Heading Level 2</h2>
  
  `,
  styles: [`
  
  .text-success{
    color: green
  }
  .text-danger{
    color: red
  }
  .text-special{
    font-style: italic
  }

  `]
})
export class Test3Component implements OnInit {

  public textSuccess = "text-success";
  public applyClass = false;
  public isSpecial = true;
  public hasError = true;
  public titleStyle = {
    color: 'blue',
    fontSize: '75px',
    fontStyle: 'italic'
  }
  public message = {
    "text-success": !this.hasError,
    "text-danger": this.hasError,
    "text-special": this.hasError
  }

  constructor() { }

  ngOnInit() {
  }

  onButtonClick(event) {
    console.log("clicked " + event.type);
  }
}
