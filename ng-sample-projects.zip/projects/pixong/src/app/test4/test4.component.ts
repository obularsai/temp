import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test4',
  template: `
  
  <h1>Test4 Component</h1>
  <input type="text" #myInput>
  <button (click)="onButtonClicked(myInput.value)"> Button </button>
  <hr>
  <h1>ngModel</h1>
  <input type="text" value="" #myInput2 [(ngModel)]="name"/>
  <button (click)="onButtonClicked2(myInput2.value)"> Button </button>
  <h1> {{ name }} </h1>
  <hr>
  <h1>Directives</h1>

  <div *ngIf="false; else elseBlock">
    <h1>Hello from If</h1>
  </div>

  <ng-template #elseBlock>
    <h1>Hello from else</h1>
  </ng-template>


  <div *ngIf="true; then thenBlock1; else elseBlock1"></div>

<ng-template #thenBlock1>
  <h1>Hello from then1</h1>
</ng-template>
<ng-template #elseBlock1>
  <h1>Hello from else1</h1>
</ng-template>


  <div style="display:none">
    <h1>Hello from CSS</h1>
  </div>

  <div [ngSwitch]="color">
  <h1 *ngSwitchCase="'red'">Case 1</h1>
  <h1 *ngSwitchCase="'blue'">Case 2</h1>
  <h1 *ngSwitchCase="'green'">Case 3</h1>
  <h1 *ngSwitchDefault>Case Default</h1>
  </div>

  `,
  styleUrls: ['./test4.component.css']
})
export class Test4Component implements OnInit {

  public name = "asdf";
  public color = "";
  constructor() { }

  ngOnInit() {
  }
  onButtonClicked(value) {
    console.log(value);
  }
  onButtonClicked2(value) {
    console.log(value);
  }
}
