import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  public name = "Mark Smith";
  public n = 12;
  public colors = ['red', 'green', 'blue'];
  constructor() {

  }

  ngOnInit() {
  }
  sayHello() {
    return "sayHello() function executed";
  }
}
