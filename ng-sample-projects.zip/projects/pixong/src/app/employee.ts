interface Employee {
    name: string;
    empId: string;
    dob: string;
    gender: string;
}