import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test6',
  templateUrl: './test6.component.html',
  styleUrls: ['./test6.component.css']
})
export class Test6Component implements OnInit {

  employees = [];

  public name = "Mark Smith";
  public message = "welcome to angular training";
  public person = {
    firstName: "Mark",
    lastName: "Smith"
  }
  public date = new Date();

  constructor() {
    this.employees = [
      { name: 'Sai', empId: 'emp001', dob: '12/25/1983', gender: 'male' },
      { name: 'Priyanka', empId: 'emp002', dob: '12/30/1983', gender: 'female' },
      { name: 'Sundar', empId: 'emp003', dob: '12/16/1983', gender: 'male' },
      { name: 'Stacy', empId: 'emp004', dob: '12/1/1983', gender: 'female' }
    ]
  }

  ngOnInit() {
  }
  refreshTable() {
    this.employees = [
      { name: 'Sai', empId: 'emp001', dob: '12/25/1983', gender: 'male' },
      { name: 'Priyanka', empId: 'emp002', dob: '12/30/1983', gender: 'female' },
      { name: 'Sundar', empId: 'emp003', dob: '12/16/1983', gender: 'male' }
    ]
  }
  trackByEmpCode(index, employee) {
    return employee.empId;
  }
}
