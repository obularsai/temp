import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestURLComponent } from './test-url.component';

describe('TestURLComponent', () => {
  let component: TestURLComponent;
  let fixture: ComponentFixture<TestURLComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestURLComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestURLComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
