import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CompanyService } from 'src/app/service/company.service';
import { Company } from 'src/app/models/company';
import { SectorService } from 'src/app/service/sector.service';
import { StockExchangeService } from 'src/app/service/stock-exchange.service';
import { Sector } from 'src/app/models/sector';
import { StockExchange } from 'src/app/models/stockExchange';
import { StockPriceService } from 'src/app/service/stock-price.service';
import { StockPrice } from 'src/app/models/stockPrice';
import { ChartDataSets, ChartOptions, ChartType } from 'chart.js';
import { Color, Label } from 'ng2-charts';

@Component({
  selector: 'compare-details',
  templateUrl: './compare-details.component.html',
  styleUrls: ['./compare-details.component.css']
})
export class CompareDetailsComponent implements OnInit {

  // Misc data
  userId: number;
  companies: Company[] = [];
  sectors: Sector[] = [];
  stockExchanges: StockExchange[] = [];
  stockPrices: StockPrice[] = [];
  generate: boolean = false;

  constructor() { }

  ngOnInit() { }
}