package com.smcharts.repo;

import org.springframework.data.repository.CrudRepository;

import com.smcharts.model.Sector;

public interface SectorRepo extends CrudRepository<Sector, Long>{

}
