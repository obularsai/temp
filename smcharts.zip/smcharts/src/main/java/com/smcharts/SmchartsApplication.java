package com.smcharts;

import java.util.stream.Stream;

import javax.annotation.Resource;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.smcharts.model.Company;
import com.smcharts.model.IPO;
import com.smcharts.model.Sector;
import com.smcharts.model.StockExchange;
import com.smcharts.model.User;
import com.smcharts.repo.CompanyRepo;
import com.smcharts.repo.IPORepo;
import com.smcharts.repo.SectorRepo;
import com.smcharts.repo.StockExchangeRepo;
import com.smcharts.repo.UserRepo;
import com.smcharts.service.StorageService;

@SpringBootApplication
public class SmchartsApplication{

	@Resource
	StorageService storageService;
	
	public static void main(String[] args) {
		SpringApplication.run(SmchartsApplication.class, args);
	}
}
