package com.cms.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.hibernate.mapping.Array;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cms.bean.AdminBean;
import com.cms.bean.ContractBean;
import com.cms.bean.SupplierBean;
import com.cms.exception.ApplicationException;
import com.cms.service.AdminService;
import com.cms.service.ContractService;
import com.cms.service.SupplierService;

@Controller
public class AdminController {

	@Autowired
	AdminService adminService;
	
	@Autowired
	SupplierService supplierService;
	
	@Autowired
	ContractService contractService;

	static Logger log = Logger.getLogger("ContractMgmt");

	@RequestMapping(value = "/addAdmin", method = RequestMethod.POST)
	public ModelAndView saveAdmin(@ModelAttribute("command") AdminBean adminBean, BindingResult result) {
		try {
			adminService.addAdmin(adminBean);
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			return new ModelAndView("applicationError");
		}
		return new ModelAndView("index","successMessage1","SuccessFully Admin Registered!!!");

	}

	@RequestMapping(value = "/loginAdmin", method = RequestMethod.POST)
	public ModelAndView loginAdmin(@RequestParam("firstName") String name, @RequestParam("password") String password) {
		AdminBean adminBean = null;
	//	List supplierList = new ArrayList<SupplierBean>();
		List contractList = new ArrayList<ContractBean>();
	//	List contractList1 = new ArrayList<>();
		Map<String, Object> model = new HashMap<String, Object>();
		try {
			adminBean = adminService.loginAdminCheck(name);
			if (password.equals(adminBean.getPassword()) && name.equals(adminBean.getFirstName())) {
					//supplierList = supplierService.fetchAllSuppliers();
					contractList = contractService.fetchAllContracts();
				//	contractList1.addAll(contractList);
				//	System.out.println("1..."+contractList1);
				//	contractList1.addAll(supplierList);
				//	System.out.println("2..."+contractList1);
					model.put("contractList",contractList);
					model.put("AdminName", name);
				return new ModelAndView("admin", model);
			} else
				return new ModelAndView("index", "message1", "Invalid Username or Password");
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			return new ModelAndView("applicationError");
		}
	}
	
	/*@RequestMapping(value = "/fetchContractForAdmin")
	public ModelAndView fetchContractForAdmin() throws ApplicationException{
			//SupplierBean supplierBean = new SupplierBean();
			//supplierBean = supplierService.fetchSupplier(contractBean.getSupplierId());
		try {
			contractBean = contractService.fetchContract(contractBean.getContractId());
			return new ModelAndView("admin", "contractList", contractBean);
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			return new ModelAndView("applicationError");
		}
	}*/
	// private AdminBean prepareModel(AdminBean adminBean) {
	// adminBean.setFirstName(adminBean.getFirstName());
	// adminBean.setLastName(adminBean.getLastName());
	// adminBean.setAge(adminBean.getAge());
	// adminBean.setGender(adminBean.getGender());
	// adminBean.setDob(adminBean.getDob());
	// adminBean.setContactNumber(adminBean.getContactNumber());
	// adminBean.setAltContactNumber(adminBean.getAltContactNumber());
	// adminBean.setEmailId(adminBean.getEmailId());
	//
	// return adminBean;
	// }

}
