package com.cms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cms.bean.SupplierBean;
import com.cms.exception.ApplicationException;
import com.cms.service.ContractService;
import com.cms.service.SupplierService;

@SessionAttributes("supplierBean")
@Controller
public class SupplierController {
	@Autowired
	SupplierService supplierService;

	@Autowired
	ContractService contractService;

	static Logger log = Logger.getLogger("ContractMgmt");

	@RequestMapping(value = "/loginSupplier", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView loginSupplier(@ModelAttribute("command") SupplierBean supplierBean1, HttpSession session) {
		if (supplierBean1.getSupplierId() != 0) {
			SupplierBean supplierBean;
			try {
				supplierBean = supplierService.loginSupplierCheck(supplierBean1.getSupplierId());

				session.setAttribute("supplierBean", supplierBean);

				if (supplierBean1.getPassword().equals(supplierBean.getPassword())
						&& supplierBean1.getSupplierId() == supplierBean.getSupplierId()) {
					if ((supplierBean.getSupplierStatus().equals("APPROVED")))
						return new ModelAndView("supplier");
					else if ((supplierBean.getSupplierStatus().equals("REJECTED")))
						return new ModelAndView("supplierLogin", "message", "You are Rejected. So You can't Login!");
					else
						return new ModelAndView("supplierLogin", "message",
								"You submitted your registration Successfully!!! You have to wait for Admin's Approval to Login!");
				} else
					return new ModelAndView("supplierLogin", "message", "Invalid Username or Password");
			} catch (ApplicationException ae) {
				log.info(ae.getMessage());
				return new ModelAndView("applicationError");
			}
		} else {
			return new ModelAndView("about");
		}
	}

	@RequestMapping(value = "/addSupplier", method = RequestMethod.POST)
	public ModelAndView saveSupplier(@ModelAttribute("command") SupplierBean supplierBean, BindingResult result,
			HttpSession session) {
		int id = 0;
		try {
			id = supplierService.addSupplier(supplierBean);

			if (id != 0)
				return new ModelAndView("supplierLogin", "successMessage",
						"SuccessFully Supplier with Id " + id + " Registered!!!");
			else
				return new ModelAndView("error");
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			return new ModelAndView("applicationError");
		}
	}

	@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws IOException {
		session.invalidate();
		return new ModelAndView("about");
	}

	@RequestMapping(value = "/fetchAllSuppliers")
	public ModelAndView fetchAllSuppliers(HttpServletRequest request, HttpSession session) {
		if (session.getAttribute("adminBean") != null) {
			List<SupplierBean> supplierList = new ArrayList<SupplierBean>();
			try {
				supplierList = supplierService.fetchAllSuppliers();
				request.setAttribute("supplierList", supplierList);
				return new ModelAndView("manageSupplier", "supplierList", supplierList);
			} catch (ApplicationException ae) {
				log.info(ae.getMessage());
				return new ModelAndView("applicationError");
			}
		} else {
			return new ModelAndView("about");
		}
	}

	@RequestMapping(value = "/fetchSupplier")
	public ModelAndView fetchSupplier(@RequestParam("supplierStatus") String status, HttpSession session) {
		if (session.getAttribute("adminBean") != null) {
			List<SupplierBean> supplierList = new ArrayList<SupplierBean>();
			try {
				supplierList = supplierService.fetchSupplier(status);
				System.out.println(supplierList);
				
				if (supplierList.size() != 0)
					return new ModelAndView("manageSupplier", "supplierList", supplierList);
				else
					return new ModelAndView("manageSupplier", "recordMessage", "No Records Found");
			} catch (ApplicationException ae) {
				log.info(ae.getMessage());
				return new ModelAndView("applicationError");
			}
		} else {
			return new ModelAndView("about");
		}
	}

	@RequestMapping(value = "/updateSupplierStatus")
	public ModelAndView updateSupplierStatus(@ModelAttribute("command") SupplierBean supplierBean, BindingResult result,
			HttpSession session) {
		if (session.getAttribute("adminBean") != null) {
			try {
				supplierService.updateSupplierStatus(supplierBean);

			} catch (ApplicationException ae) {
				log.info(ae.getMessage());
				return new ModelAndView("applicationError");
			}

			return new ModelAndView("admin");
		} else {
			return new ModelAndView("about");
		}
	}

	@RequestMapping(value = "/fetchIdSuppliers")
	public ModelAndView fetchSuppliers(HttpSession session) {
		if (session.getAttribute("supplierBean") != null) {
			List<SupplierBean> supplierList = new ArrayList<SupplierBean>();
			Map<String, Object> model = new HashMap<String, Object>();
			try {
				supplierList = supplierService.fetchAllSuppliers();
				model.put("supplierIdList", supplierList);
				return new ModelAndView("admin", model);
			} catch (ApplicationException ae) {
				log.info(ae.getMessage());
				return new ModelAndView("applicationError");
			}
		} else {
			return new ModelAndView("about");
		}
	}
}
