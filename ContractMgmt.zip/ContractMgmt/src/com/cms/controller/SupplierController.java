package com.cms.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cms.bean.SupplierBean;
import com.cms.exception.ApplicationException;
import com.cms.service.ContractService;
import com.cms.service.SupplierService;
import com.cms.bean.ContractBean;

@Controller
public class SupplierController {
	@Autowired
	SupplierService supplierService;

	@Autowired
	ContractService contractService;

	static Logger log = Logger.getLogger("ContractMgmt");

	@RequestMapping(value = "/loginSupplier", method = RequestMethod.POST)
	public ModelAndView loginSupplier(@RequestParam("firstName") String name, @RequestParam("password") String password,
			HttpSession session) {

		SupplierBean supplierBean;
		try {
			supplierBean = supplierService.loginSupplierCheck(name);

			session.setAttribute("supplierBean", supplierBean);

			if (password.equals(supplierBean.getPassword()) && name.equals(supplierBean.getFirstName()))
				return new ModelAndView("supplier");
			else
				return new ModelAndView("index","message","Invalid Username or Password");
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			return new ModelAndView("applicationError");
		}
	}

	@RequestMapping(value = "/addSupplier", method = RequestMethod.POST)
	public ModelAndView saveSupplier(@ModelAttribute("command") SupplierBean supplierBean, BindingResult result) {
		int id = 0;
		try {
			id = supplierService.addSupplier(supplierBean);
			System.out.println(id);
			if (id != 0)
				return new ModelAndView("index","successMessage","SuccessFully Supplier Registered!!!");
			else
				return new ModelAndView("error");
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			return new ModelAndView("applicationError");
		}
	}

	@RequestMapping("/logoutSupplier")
	public ModelAndView logoutSupplier(HttpSession session) {
		session.invalidate();
		return new ModelAndView("index");
	}

	@RequestMapping(value = "/fetchAllSuppliers")
	public ModelAndView fetchAllSuppliers(HttpServletRequest request ) {
		List<SupplierBean> supplierList = new ArrayList<SupplierBean>();
		try {
			supplierList = supplierService.fetchAllSuppliers();
			request.setAttribute("supplierList",supplierList);
			return new ModelAndView("admin", "supplierList", supplierList);
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			return new ModelAndView("applicationError");
		}
	}
	
	@RequestMapping(value = "/fetchSupplier")
	public ModelAndView fetchSupplier(@RequestParam("supplierStatus") String status) {
		List<SupplierBean> supplierList = new ArrayList<SupplierBean>();
		try {
			supplierList = supplierService.fetchSupplier(status);
			return new ModelAndView("admin", "supplierList", supplierList);
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			return new ModelAndView("applicationError");
		}
	}

	@RequestMapping(value = "/updateSupplierStatus")
	public ModelAndView updateSupplierStatus(@ModelAttribute("command") SupplierBean supplierBean,
			BindingResult result) {

		try {
			supplierService.updateSupplierStatus(supplierBean);

		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			return new ModelAndView("applicationError");
		}

		return new ModelAndView("admin");
	}
	
	@RequestMapping(value = "/fetchIdSuppliers")
	public ModelAndView fetchSuppliers() {
		List<SupplierBean> supplierList = new ArrayList<SupplierBean>();
		//List<ContractBean> contractList = new ArrayList<ContractBean>();
		Map<String, Object> model = new HashMap<String, Object>();
		try {
			supplierList = supplierService.fetchAllSuppliers();
			//contractList = contractService.listContract();
			model.put("supplierIdList", supplierList);
		//	model.put("contractList", contractList);
			return new ModelAndView("admin",model);
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			return new ModelAndView("applicationError");
		}
	}
	
	@RequestMapping(value = "/fetchContractUsingSupplierId")
	public ModelAndView fetchContractUsingSupplierId(@ModelAttribute("command") ContractBean contractBean, BindingResult result) throws ApplicationException{
			SupplierBean supplierBean = new SupplierBean();
			supplierBean = supplierService.fetchSupplier(contractBean.getSupplierId());
		List<ContractBean> contractIdList, contractIdList1 = new ArrayList<ContractBean>();
		try {
			contractIdList = contractService.listContract();
			for (ContractBean contract : contractIdList) {
				if (contract.getSupplierId() == supplierBean.getSupplierId()) {
					contractIdList1.add(contract);
				}
			}
			return new ModelAndView("admin", "contractIdList", contractIdList1);
		} catch (ApplicationException ae) {
			log.info(ae.getMessage());
			return new ModelAndView("applicationError");
		}
	}

}
