package com.cms.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.bean.ContractBean;
import com.cms.entity.ContractEntity;
import com.student.entity.StudentEntity;

@Repository("contractDao")
public class ContractDaoImpl implements ContractDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public int addContract(ContractBean contractBean) {
		int id = 0;
		// TODO Auto-generated method stub
		try {
			ContractEntity contractEntity = new ContractEntity();
			
			contractEntity.setContractDesc(contractBean.getContractDesc());
			contractEntity.setContractProDate(contractBean.getContractProDate());
			contractEntity.setContractSubDate(contractBean.getContractSubDate());
			contractEntity.setContractStatus(contractBean.getContractStatus());
			contractEntity.setSupplierId(contractBean.getSupplierId());
			
			sessionFactory.getCurrentSession().saveOrUpdate(contractEntity);
			
			contractEntity = (ContractEntity) sessionFactory.getCurrentSession().get(ContractEntity.class, contractEntity.getContractId());
			id = contractEntity.getContractId();
			System.out.println("******"+id+"******");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return id;
	}

	@Override
	public List<ContractBean> listContract() {
		// TODO Auto-generated method stub
		List<ContractBean> contractDetails = null;

		try {
			List list = sessionFactory.getCurrentSession().createQuery("from ContractEntity").list();
			contractDetails = new ArrayList();

			for (int i = 0; i < list.size(); i++) {
				ContractBean contractBean = new ContractBean();
				ContractEntity contractEntity = (ContractEntity) list.get(i);
				contractBean.setContractId(contractEntity.getContractId());
				contractBean.setContractDesc(contractEntity.getContractDesc());
				contractBean.setContractSubDate(contractEntity.getContractSubDate());
				contractBean.setContractProDate(contractEntity.getContractProDate());
				contractBean.setContractStatus(contractEntity.getContractStatus());
				contractBean.setSupplierId(contractEntity.getSupplierId());
				
				contractDetails.add(contractBean);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return contractDetails;
	}

}
