package com.cms.dao;

import com.cms.bean.ContractBean;

public interface AmenityDao {

	public int addAmenity(ContractBean contractBean);

}
