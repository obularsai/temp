package com.cms.service;

import com.cms.bean.AdminBean;

public interface AdminService {

	public int addAdmin(AdminBean adminBean);
	
	public String loginAdminCheck(String name);
	
	
}
