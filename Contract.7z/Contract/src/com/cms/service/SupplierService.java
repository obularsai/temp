package com.cms.service;

import com.cms.bean.SupplierBean;

public interface SupplierService {

	public SupplierBean loginSupplierCheck(String name);
	
	public int addSupplier(SupplierBean supplierBean);
}
