package com.cms.service;

import com.cms.bean.ContractBean;

public interface AmenityService {
	
	public int addAmenity(ContractBean contractBean);
	
}
