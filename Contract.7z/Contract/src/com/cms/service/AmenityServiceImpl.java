package com.cms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.bean.ContractBean;
import com.cms.dao.AmenityDao;

@Service("amenityService")
public class AmenityServiceImpl implements AmenityService{
	
	@Autowired
	AmenityDao amenityDao;

	@Override
	public int addAmenity(ContractBean contractBean) {
		// TODO Auto-generated method stub
		return amenityDao.addAmenity(contractBean);
	}

}
