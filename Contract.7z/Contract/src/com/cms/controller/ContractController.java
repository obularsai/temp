package com.cms.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cms.bean.ContractBean;
import com.cms.service.AmenityService;
import com.cms.service.ContractService;
import com.cms.service.TermsAndConditionsService;

@Controller
public class ContractController {

	@Autowired
	ContractService contractService;
	@Autowired
	TermsAndConditionsService tacService;	
	@Autowired
	AmenityService amenityService;
	
	@RequestMapping("/addContract")
	public ModelAndView addContract(@ModelAttribute("command") ContractBean contractBean, BindingResult result){
		List<ContractBean> contractList = new ArrayList<ContractBean>();
		//contractList = contractService.listContract();
		int id = contractService.addContract(contractBean);
		
		System.out.println(id);
		
		contractBean.setContractId(id);
		int k = tacService.addTac(contractBean);
		amenityService.addAmenity(contractBean);
		if(k != 0)
			return new ModelAndView("supplierPage", "contractList",contractList);
		else
			return new ModelAndView("error");
	}
	
	@RequestMapping("/contractList")
	public ModelAndView listContract(){
		List<ContractBean> contractList = new ArrayList<ContractBean>();
		contractList = contractService.listContract();
		if(contractList != null)
			return new ModelAndView("supplierPage", "contractList", contractList);
		else
			return new ModelAndView("error");
	}
}
